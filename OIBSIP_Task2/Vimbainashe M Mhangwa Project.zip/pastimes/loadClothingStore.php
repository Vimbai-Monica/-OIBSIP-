<?php

// Include the database connection
include 'DBConn.php'; // Ensure this line is present

$sqlFile = 'MyClothingStore.sql';

// Enable error reporting for mysqli
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

// Check if the SQL file exists
if (file_exists($sqlFile)) {
    // Get the contents of the SQL file
    $sqlCommands = file_get_contents($sqlFile);
    // Split the SQL commands into an array
    $sqlStatements = explode(';', $sqlCommands);

    // Disable foreign key checks to avoid constraint issues
    $dbConnection->query('SET FOREIGN_KEY_CHECKS = 0;');

    // Drop the existing tables if they exist
    $dropTablesSQL = "DROP TABLE IF EXISTS tblAdmin, tblSeller, tblUser, tblClothes, tblAorder, tbl_item;";
    
    // Execute the drop tables query
    if ($dbConnection->query($dropTablesSQL) === TRUE) {
        echo 'Existing tables dropped successfully.<br>';
        
        // Loop through each SQL statement from the file
        foreach ($sqlStatements as $sql) {
            $sql = trim($sql);
            // Create the table only if the statement is not empty
            if (!empty($sql)) {
                try {
                    // Execute the SQL statement
                    if ($dbConnection->query($sql) === TRUE) {
                        echo 'Table created successfully.<br>';
                    } else {
                        echo 'Error creating table: ' . $dbConnection->error . '<br>';
                    }
                } catch (Exception $e) {
                    echo 'Error executing query: ' . $e->getMessage() . '<br>';
                }
            }
        }

        
        // Create the seller_requests table
        $createSellerRequestsTableSQL = "
        CREATE TABLE IF NOT EXISTS seller_requests (
            requestID INT AUTO_INCREMENT PRIMARY KEY,
            userID INT NOT NULL,
            status ENUM('pending', 'approved', 'rejected') NOT NULL DEFAULT 'pending',
            requestDate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            adminResponseDate TIMESTAMP NULL,
            FOREIGN KEY (userID) REFERENCES users(userID) ON DELETE CASCADE
        );";
        
        // Execute the query to create the seller_requests table
        if ($dbConnection->query($createSellerRequestsTableSQL) === TRUE) {
            echo 'seller_requests table created successfully.<br>';
        } else {
            echo 'Error creating seller_requests table: ' . $dbConnection->error . '<br>';
        }

        // Create the message_replies table
        $createMessageRepliesTableSQL = "
        CREATE TABLE IF NOT EXISTS message_replies (
            replyID INT(11) NOT NULL AUTO_INCREMENT,
            messageID INT(11) NOT NULL,
            senderID INT(11) NOT NULL,
            replyMessage TEXT NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (replyID),
            KEY messageID (messageID),
            KEY senderID (senderID),
            FOREIGN KEY (messageID) REFERENCES admin_messages(messageID) ON DELETE CASCADE
        ) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;";

        // Execute the query to create the message_replies table
        if ($dbConnection->query($createMessageRepliesTableSQL) === TRUE) {
            echo 'message_replies table created successfully.<br>';
        } else {
            echo 'Error creating message_replies table: ' . $dbConnection->error . '<br>';
        }

        // Create the admin_messages table
        $createAdminMessagesTableSQL = "
        CREATE TABLE IF NOT EXISTS admin_messages (
            messageID INT(11) NOT NULL AUTO_INCREMENT,
            recipientID INT(11) NOT NULL,
            recipientType ENUM('user', 'seller') NOT NULL,
            message TEXT NOT NULL,
            status ENUM('unread', 'read') DEFAULT 'unread',
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (messageID)
        ) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=utf8;";

        // Execute the query to create the admin_messages table
        if ($dbConnection->query($createAdminMessagesTableSQL) === TRUE) {
            echo 'admin_messages table created successfully.<br>';
        } else {
            echo 'Error creating admin_messages table: ' . $dbConnection->error . '<br>';
        }

    } else {
        echo 'Error dropping tables: ' . $dbConnection->error . '<br>';
    }
   

    // Re-enable foreign key checks
    $dbConnection->query('SET FOREIGN_KEY_CHECKS = 1;');
}else {
    echo 'SQL file not found: ' . $sqlFile . '<br>';
}

// Close the connection
$dbConnection->close();  // Close the connection

?>

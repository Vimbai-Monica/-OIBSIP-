<?php
session_start();
include 'DBConn.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Pastimes is your go-to online store for high-quality branded used clothing, offering top-notch fashion at affordable prices.">
    <meta name="keywords" content="clothing store, online shopping, used clothing, affordable fashion, Pastimes, fashion">
    <meta name="revisit" content="30 days">
    <meta http-equiv="refresh" content="30">
    <meta name="robots" content="noindex, nofollow">
    <title>Pastimes About Page</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <header>
        <div class="header-container">
            <div class="logo-container">
                <img src="_images/pastimes_logo.png" alt="Pastimes Logo" width="150">
            </div>

            <div class="search-container">
                <input type="text" placeholder="Search for items..." class="search-bar" id="search-input">
                <button class="search-button" id="search-button">Search</button>
            </div>

            <script>
                document.getElementById('search-button').addEventListener('click', function() {
                    const query = document.getElementById('search-input').value;
                    if (query) {
                        // Perform the search action here. For example, you can redirect to a search results page:
                        alert('Searching for: ' + query); // Replace this line with your search functionality
                        // window.location.href = 'search-results.html?query=' + encodeURIComponent(query);
                    } else {
                        alert('Please enter a search term.');
                    }
                });

                // Optional: Enable searching by pressing Enter in the input field
                document.getElementById('search-input').addEventListener('keypress', function(event) {
                    if (event.key === 'Enter') {
                        document.getElementById('search-button').click();
                    }
                });
            </script>

            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li class="currentPage">About Us</li>
                    <li><a href="catalogue.php">Catalogue</a></li>
                    <li><a href="cart.php"><img src="_images/cart_icon.jpeg" alt="Cart Icon" width="20"> Cart</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li><a href="user_dashboard.php">Dashboard</a></li>
                    <li><a href="logout.php">Log Out</a></li>
                </ul>
            </nav>
        </div>
    </header>


    <!-- Display logged-in user's name -->
    <?php
    if (isset($_SESSION['name'])) {
        // Display the logged-in message
        echo "<p>User " . htmlspecialchars($_SESSION['name']) . " is logged in.</p>";
    } else {
        // Display a message for users who are not logged in
        echo "<p>Welcome, guest! Please log in to access more features.</p>";
    }
    ?>

    <main>
        <section id="about-us">
            <h2>About Pastimes</h2>

            <div class="section">
                <h3>Introduction</h3>
                <p>At Pastimes, we are dedicated to providing a sustainable and stylish shopping experience. Our curated collection of high-quality branded used clothing is designed for fashion-forward individuals who care about the environment.</p>
            </div>

            <div class="section">
                <h3>Values</h3>
                <p>We believe in integrity, sustainability, and community. Our commitment to ethical practices ensures that every item we sell has been responsibly sourced and given a second chance.</p>
            </div>

            <div class="section">
                <h3>Culture</h3>
                <p>Our culture is centered around creativity and inclusivity. We celebrate diversity and encourage everyone to express their unique style through fashion.</p>
            </div>

            <div class="section">
                <h3>Mission</h3>
                <p>Our mission is to make fashion sustainable and accessible. We aim to reduce waste in the fashion industry by promoting the reuse of clothing.</p>
            </div>

            <div class="section">
                <h3>Vision</h3>
                <p>We envision a world where fashion is not only about trends but also about sustainability. Our goal is to lead the way in promoting environmentally friendly practices in the fashion industry.</p>
            </div>

            <div class="section">
                <h3>Background</h3>
                <p>Founded in 2020, Pastimes began as a small initiative to promote the benefits of second-hand clothing. Over the years, we have grown into a trusted online store, known for our quality and commitment to sustainability.</p>
            </div>
        </section>
    </main>

    <footer>
        <!-- Menu -->
        <div id="footer-menu" class="footer-section">
            <!-- Bottom Navigation Menu -->

            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li class="currentPage">About Us</li>
                    <li><a href="catalogue.php">Catalogue</a></li>
                    <li><a href="cart.php"><img src="_images/cart_icon.jpeg" alt="Cart Icon" width="20"> Cart</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li><a href="user_dashboard.php">Dashboard</a></li>
                </ul>
            </nav>
        </div>


        <div id="footer-content">
            <!-- Lets Connect -->
            <div id="social-media-footer" class="footer-section">
                <h4>Lets Connect</h4>
                <div>
                    <a href="https://www.instagram.com/moni_que360" target="_blank">
                        <img src="_images/instagram_icon.jpg" alt="Instagram Icon" width="3%"> @moni_que360</a>
                </div>
                <div>
                    <a href="https://www.facebook.com/pastime.fb/" target="_blank">
                        <img src="_images/facebook_icon.jpg" alt="Facebook Icon" width="3%"> Facebook</a>
                </div>
                <!-- Email -->
                <div>
                    <p><a href="mailto:pastimes23@gmail.com">pastimes23@gmail.com</a></p>
                </div>
            </div>
            <!-- Contact Information -->
            <div id="contact-info-footer-left" class="footer-section">
                <!-- Address -->
                <div class="address">
                    <h4><u>Address</u></h4>
                    <p><img src="_images/location_icon.jpg" alt="Address Icon" width="5%"> 19 Lyster Crescent, <br>
                        Randpark Ridge, <br>
                        Randburg, Johannesburg, 2169</p>
                </div>
                <!-- Working Hours -->
                <div class="working-hours">
                    <h4><u>Working hours:</u></h4>
                    <p class="no-break">Monday to Saturday: Open 24 hours</p>
                    <p class="no-break">Sunday: Closed</p>
                </div>
            </div>
        </div>
    </footer>

</body>

</html>
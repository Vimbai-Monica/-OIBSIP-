<?php
session_start();
include 'DBConn.php';

// Fetch all items from the database
$query = "SELECT * FROM tbl_item";
$result = $dbConnection->query($query);

// Initialize items array
$items = [];
if ($result->num_rows > 0) {
    // Fetch each row as an associative array and push it into the $items array
    while ($row = $result->fetch_assoc()) {
        $items[] = [
            'item_id' => $row['item_id'],  // Ensure item_id is included for use in the cart
            'item_name' => $row['item_name'],
            'item_description' => $row['item_description'],
            'price' => $row['price'],
            'image_path' => $row['image_path'],
            'category' => $row['category'],
            'clothesCondition' => $row['clothesCondition']
        ];
    }
} else {
    echo "No items found!";
}

// Initialize cart if it doesn't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

// Add item to cart function
if (isset($_GET['add_to_cart'])) {
    $item_id = $_GET['add_to_cart'];

    // Query to fetch item details from the database
    $query = "SELECT * FROM tbl_item WHERE item_id = ?";
    $stmt = $dbConnection->prepare($query);
    $stmt->bind_param("i", $item_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $item = $result->fetch_assoc();

        // Check if the item is already in the cart
        $item_exists_in_cart = false;
        foreach ($_SESSION['cart'] as &$cart_item) {
            if ($cart_item['item_id'] == $item['item_id']) {
                // If item is already in the cart, increase the quantity by 1
                $cart_item['quantity'] += 1;
                $item_exists_in_cart = true;
                break;
            }
        }

        // If item doesn't exist in cart, add it with quantity 1
        if (!$item_exists_in_cart) {
            // Add item to the cart with initial quantity of 1
            $item['quantity'] = 1;
            $_SESSION['cart'][] = $item;
        }

        $_SESSION['cart_message'] = $item_exists_in_cart ? "Item quantity updated in cart!" : "Item successfully added to cart!";
    } else {
        $_SESSION['cart_message'] = "Item not found.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Pastimes is your go-to online store for high-quality branded used clothing, offering top-notch fashion at affordable prices.">
    <meta name="keywords" content="clothing store, online shopping, used clothing, affordable fashion, Pastimes, fashion">
    <meta name="revisit" content="30 days">
    <meta http-equiv="refresh" content="30">
    <meta name="robots" content="noindex, nofollow">
    <title>Pastimes Item List</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <!-- Display logged-in user's name -->
    <?php
    if (isset($_SESSION['name'])) {
        echo "<p>User " . htmlspecialchars($_SESSION['name']) . " is logged in.</p>";
    } else {
        echo "<p>Welcome, guest! Please log in to access more features.</p>";
    }
    ?>

    <!-- Display cart message if an item is added -->
    <?php
    if (isset($_SESSION['cart_message'])) {
        echo "<p>{$_SESSION['cart_message']}</p>";
        unset($_SESSION['cart_message']); // Clear message after showing it
    }
    ?>


    <h1>Items Available</h1>

    <!-- Link to go back to the catalogue page -->
    <p><a href="catalogue.php">Click here to go back to the catalogue page</a></p>

    <!-- Table Display -->
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Description</th>
                <th>Price</th>
                <th>Image</th>
                <th>Category</th>
                <th>Condition</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $item): ?>
                <tr>
                    <td><?php echo htmlspecialchars($item['item_name']); ?></td>
                    <td><?php echo htmlspecialchars($item['item_description']); ?></td>
                    <td>R <?php echo htmlspecialchars($item['price']); ?></td>
                    <td>
                        <img src="<?php echo file_exists($item['image_path']) ? htmlspecialchars($item['image_path']) : 'path/to/default-image.jpg'; ?>" alt="<?php echo htmlspecialchars($item['item_name']); ?>" width="100" height="100">
                    </td>
                    <td><?php echo htmlspecialchars($item['category']); ?></td>
                    <td><?php echo htmlspecialchars($item['clothesCondition']); ?></td>
                    <td>
                        <!-- Add to Cart button with link to add item -->
                        <a href="?add_to_cart=<?php echo $item['item_id']; ?>">
                            <button class="add-to-cart-btn">Add to Cart</button>
                            <!-- Show Cart Button -->
                            <p><a href="cart.php"><button>Show Cart</button></a></p>
                        </a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Link to go back to the catalogue page -->
    <p><a href="catalogue.php">Click here to go back to the catalogue page</a></p>


</body>

</html>
-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 10, 2024 at 02:39 AM
-- Server version: 5.7.40
-- PHP Version: 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clothingstore`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_messages`
--

DROP TABLE IF EXISTS `admin_messages`;
CREATE TABLE IF NOT EXISTS `admin_messages` (
  `messageID` int(11) NOT NULL AUTO_INCREMENT,
  `recipientID` int(11) NOT NULL,
  `recipientType` enum('user','seller') NOT NULL,
  `message` text NOT NULL,
  `status` enum('unread','read') DEFAULT 'unread',
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`messageID`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=hp8;

--
-- Dumping data for table `admin_messages`
--

INSERT INTO `admin_messages` (`messageID`, `recipientID`, `recipientType`, `message`, `status`, `timestamp`) VALUES
(1, 1, 'user', 'Your request has been approved. Please proceed with the next steps.', 'read', '2024-11-10 12:00:00'),
(2, 2, 'seller', 'Your item has been listed successfully. Please ensure all details are accurate.', 'unread', '2024-11-10 12:15:00'),
(3, 3, 'user', 'We are currently working on your request and will get back to you soon.', 'unread', '2024-11-10 12:30:00'),
(5, 5, 'seller', 'Your payment has been processed successfully. Please check your account for details.', 'unread', '2024-11-10 13:00:00'),
(7, 7, 'user', 'We have successfully received your feedback. Thank you for sharing your thoughts.', 'unread', '2024-11-10 13:30:00'),
(8, 8, 'seller', 'Please note that your item needs to be re-listed with updated details to meet our guidelines.', 'unread', '2024-11-10 13:45:00'),
(10, 10, 'user', 'Your inquiry has been marked as resolved. Please let us know if further assistance is needed.', 'unread', '2024-11-10 14:15:00'),
(11, 1, 'user', 'Your complaint is being addressed. You will receive a resolution shortly.', 'read', '2024-11-10 14:30:00'),
(12, 2, 'seller', 'Your recent transaction was completed successfully. Please ensure all buyer details are accurate.', 'unread', '2024-11-10 14:45:00'),
(14, 4, 'user', 'We have reviewed your case and will proceed with the necessary actions.', 'unread', '2024-11-10 15:15:00'),
(15, 5, 'seller', 'Your account is now active. You can now list your products on the platform.', 'unread', '2024-11-10 15:30:00'),
(17, 7, 'seller', 'Your feedback has been reviewed, and we appreciate your input. We are working to improve our services.', 'unread', '2024-11-10 16:00:00'),
(18, 8, 'user', 'We regret to inform you that your request has been denied. Please contact support for further assistance.', 'unread', '2024-11-10 16:15:00'),
(20, 10, 'seller', 'We have reviewed your item and would like to suggest some changes before listing it.', 'unread', '2024-11-10 16:45:00'),
(21, 1, 'user', 'Your request has been approved, and the required steps are outlined in the attached document.', 'read', '2024-11-10 17:00:00'),
(23, 3, 'seller', 'Your recent item listing has been flagged for review due to policy violations.', 'unread', '2024-11-10 17:30:00'),
(24, 4, 'user', 'We have successfully processed your payment. You will receive an email confirmation shortly.', 'unread', '2024-11-10 17:45:00'),
(25, 5, 'seller', 'Your item has been successfully sold. Please ensure that the shipping is completed on time.', 'unread', '2024-11-10 18:00:00'),
(26, 6, 'user', 'Your request has been denied. Please contact customer support for further clarification.', 'unread', '2024-11-10 18:15:00'),
(27, 7, 'seller', 'We appreciate your message and are currently reviewing the feedback you provided. Thank you for your time.', 'unread', '2024-11-10 18:30:00'),
(28, 8, 'user', 'We are currently investigating the issue you raised. Please expect an update soon.', 'unread', '2024-11-10 18:45:00'),
(30, 10, 'seller', 'Thank you for your patience. Your request is now being processed and will be completed shortly.', 'unread', '2024-11-10 19:15:00'),
(6, 1, 'user', 'Your account has been successfully updated. Please check your profile for details.', 'read', '2024-11-10 19:30:00'),
(4, 1, 'user', 'Your account has been successfully updated. Please check your profile for details.', 'read', '2024-11-10 19:30:00'),
(29, 1, 'user', 'Your account has been successfully updated. Please check your profile for details.', 'read', '2024-11-10 19:30:00'),
(22, 2, 'seller', 'Your product has been successfully shipped. Please keep the buyer updated on the delivery status.', 'unread', '2024-11-10 19:45:00'),
(9, 3, 'user', 'We are reviewing your case and will notify you once a resolution is reached.', 'unread', '2024-11-10 20:00:00'),
(13, 3, 'user', 'We are reviewing your case and will notify you once a resolution is reached.', 'unread', '2024-11-10 20:00:00'),
(16, 8, 'seller', 'Your recent payment has been successfully processed. You can now withdraw funds from your account.', 'unread', '2024-11-10 21:15:00'),
(19, 8, 'seller', 'Your recent payment has been successfully processed. You can now withdraw funds from your account.', 'unread', '2024-11-10 21:15:00');

-- --------------------------------------------------------

--
-- Table structure for table `message_replies`
--

DROP TABLE IF EXISTS `message_replies`;
CREATE TABLE IF NOT EXISTS `message_replies` (
  `replyID` int(11) NOT NULL AUTO_INCREMENT,
  `messageID` int(11) NOT NULL,
  `senderID` int(11) NOT NULL,
  `replyMessage` text NOT NULL,
  `timestamp` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`replyID`),
  KEY `messageID` (`messageID`),
  KEY `senderID` (`senderID`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=hp8;

--
-- Dumping data for table `message_replies`
--

INSERT INTO `message_replies` (`replyID`, `messageID`, `senderID`, `replyMessage`, `timestamp`) VALUES
(1, 1, 1, 'Thank you for your message. I will look into it and get back to you shortly.', '2024-11-10 12:00:00'),
(2, 2, 3, 'I have received your message and will respond as soon as possible.', '2024-11-10 12:15:00'),
(3, 3, 2, 'Apologies for the delay, I am currently checking the status of your request.', '2024-11-10 12:30:00'),
(4, 4, 8, 'Thank you for contacting us. We are looking into the issue and will resolve it soon.', '2024-11-10 12:45:00'),
(5, 5, 1, 'Your request is being processed, and we will update you once it is completed.', '2024-11-10 13:00:00'),
(6, 6, 10, 'We have received your inquiry and will get back to you as soon as possible.', '2024-11-10 13:15:00'),
(7, 7, 9, 'Thanks for reaching out! I will follow up with the team and provide you with an update.', '2024-11-10 13:30:00'),
(8, 8, 5, 'Your request has been received and is being processed. Expect an update soon.', '2024-11-10 13:45:00'),
(9, 9, 6, 'Thank you for your patience. I am reviewing your request and will respond shortly.', '2024-11-10 14:00:00'),
(10, 10, 7, 'We appreciate your message. I will investigate the matter and get back to you as soon as possible.', '2024-11-10 14:15:00'),
(11, 11, 8, 'Your message has been received. I will look into the issue and follow up with you shortly.', '2024-11-10 14:30:00'),
(12, 12, 9, 'I have reviewed your inquiry, and I will ensure that you get a timely response.', '2024-11-10 14:45:00'),
(13, 13, 5, 'Thanks for reaching out. I am currently working on your request and will keep you updated.', '2024-11-10 15:00:00'),
(14, 14, 6, 'I will get back to you shortly with more details. Thanks for your patience.', '2024-11-10 15:15:00'),
(15, 15, 7, 'Your message has been acknowledged. I will be addressing your concerns shortly.', '2024-11-10 15:30:00'),
(16, 16, 8, 'Thanks for your message. I will follow up with the relevant team and provide you with an update.', '2024-11-10 15:45:00'),
(17, 17, 10, 'Your inquiry has been received. I will respond shortly with further details.', '2024-11-10 16:00:00'),
(18, 18, 9, 'I have reviewed your request and will get back to you as soon as possible.', '2024-11-10 16:15:00'),
(19, 19, 6, 'Your request has been successfully received. I will let you know the next steps shortly.', '2024-11-10 16:30:00'),
(20, 20, 5, 'Thank you for your message. I am currently reviewing your inquiry and will respond shortly.', '2024-11-10 16:45:00'),
(21, 21, 7, 'Your inquiry is being processed, and I will provide an update soon.', '2024-11-10 17:00:00'),
(22, 22, 8, 'I have reviewed your request and will be in touch with an update shortly.', '2024-11-10 17:15:00'),
(23, 23, 9, 'Your request has been noted. I am working on it and will get back to you as soon as I can.', '2024-11-10 17:30:00'),
(24, 24, 5, 'Thanks for your patience. I am addressing the issue now and will provide an update shortly.', '2024-11-10 17:45:00'),
(25, 25, 6, 'I am currently working on your request and will send an update soon. Thank you for your understanding.', '2024-11-10 18:00:00'),
(26, 26, 7, 'Thank you for your inquiry. I will follow up with the necessary details shortly.', '2024-11-10 18:15:00'),
(27, 27, 8, 'Your message has been received. I will ensure that the issue is resolved as soon as possible.', '2024-11-10 18:30:00'),
(28, 28, 9, 'Thanks for reaching out. I am currently reviewing your inquiry and will update you soon.', '2024-11-10 18:45:00'),
(29, 29, 10, 'I have received your message and am working on resolving the issue. I will update you shortly.', '2024-11-10 19:00:00'),
(30, 30, 5, 'Thank you for your message. I will respond shortly with more details after reviewing your request.', '2024-11-10 19:15:00');

-- --------------------------------------------------------

--
-- Table structure for table `seller_requests`
--

DROP TABLE IF EXISTS `seller_requests`;
CREATE TABLE IF NOT EXISTS `seller_requests` (
  `requestID` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `status` enum('pending','approved','rejected') DEFAULT 'pending',
  `requestDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `adminResponseDate` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`requestID`),
  KEY `userID` (`userID`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=hp8;

--
-- Dumping data for table `seller_requests`
--

INSERT INTO `seller_requests` (`requestID`, `userID`, `status`, `requestDate`, `adminResponseDate`) VALUES
(1, 1, 'pending', '2024-09-22 09:10:00', NULL),
(2, 2, 'approved', '2024-10-03 09:15:00', '2024-10-03 10:00:00'),
(3, 3, 'rejected', '2024-10-05 09:20:00', '2024-10-05 10:30:00'),
(4, 4, 'pending', '2024-10-07 09:25:00', NULL),
(5, 5, 'approved', '2024-10-12 09:30:00', '2024-10-12 11:00:00'),
(6, 6, 'rejected', '2024-10-14 09:35:00', '2024-10-14 11:30:00'),
(7, 7, 'pending', '2024-10-17 09:40:00', NULL),
(8, 8, 'approved', '2024-10-18 09:45:00', '2024-10-18 12:00:00'),
(9, 9, 'rejected', '2024-10-19 09:50:00', '2024-10-19 12:30:00'),
(10, 10, 'pending', '2024-10-20 09:55:00', NULL),
(11, 11, 'approved', '2024-10-21 10:00:00', '2024-10-21 13:00:00'),
(12, 12, 'rejected', '2024-10-22 10:05:00', '2024-10-22 13:30:00'),
(13, 13, 'pending', '2024-10-23 10:10:00', NULL),
(14, 14, 'approved', '2024-10-24 10:15:00', '2024-10-24 14:00:00'),
(15, 15, 'rejected', '2024-10-25 10:20:00', '2024-10-25 14:30:00'),
(16, 16, 'pending', '2024-10-26 10:25:00', NULL),
(17, 17, 'approved', '2024-10-27 10:30:00', '2024-10-27 15:00:00'),
(18, 18, 'rejected', '2024-10-28 10:35:00', '2024-10-28 15:30:00'),
(19, 19, 'pending', '2024-10-29 10:40:00', NULL),
(20, 20, 'approved', '2024-10-30 10:45:00', '2024-10-30 16:00:00'),
(21, 21, 'rejected', '2024-11-01 10:50:00', '2024-11-01 16:30:00'),
(22, 22, 'pending', '2024-11-02 10:55:00', NULL),
(23, 23, 'approved', '2024-11-03 11:00:00', '2024-11-03 17:00:00'),
(24, 24, 'rejected', '2024-11-04 11:05:00', '2024-11-04 17:30:00'),
(25, 25, 'pending', '2024-11-05 11:10:00', NULL),
(26, 26, 'approved', '2024-11-06 11:15:00', '2024-11-06 18:00:00'),
(27, 27, 'rejected', '2024-11-07 11:20:00', '2024-11-07 18:30:00'),
(28, 28, 'pending', '2024-11-08 11:25:00', NULL),
(29, 29, 'approved', '2024-11-09 11:30:00', '2024-11-09 19:00:00'),
(30, 30, 'rejected', '2024-11-10 11:35:00', '2024-11-10 19:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `tbladmin`
--

DROP TABLE IF EXISTS `tbladmin`;
CREATE TABLE IF NOT EXISTS `tbladmin` (
  `adminID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  PRIMARY KEY (`adminID`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=hp8;

--
-- Dumping data for table `tbladmin`
--

INSERT INTO `tbladmin` (`adminID`, `name`, `username`, `password`, `email`) VALUES
(1, 'Clasey Kanyemba', 'ckanyemba', '$2y$10$7RgBKGbWl34KAXXc.sp1rOzOPkjCc371v4HLGUM5.RKCcIPRBS9Iq', 'ckanyemba@gmail.com'),
(2, 'David White', 'dwhite', '$2y$10$8EbpdYcGlVd9Yw1OI1L1TemSL0GjhYPeGoxjIkyLiTRVszk26i5qC', 'dwhite@bing.com'),
(3, 'Olivia Black', 'oblack', '$2y$10$rpWKXoczXKpTnK6rW5zP3Ol3vaI1f0arTXlyTSbwhkM713.wbZlgW', 'oblack@well.com'),
(4, 'James Blue', 'jblue', '$2y$10$qKxCYXEpIkcG/Nu/tlC0pOa/vpngNK.6uivBASNuYMA0tybr0Z5NK', 'jblue@example.com'),
(5, 'Sophia Red', 'sred', '$2y$10$Flh5z4j/H0BFetXef4TSAOwe/iTYL6x9GgwAMHMizT13bY/8CET7m', 'sred@dibbs.com'),
(6, 'Monica Mhangwa', 'vim', '$2y$10$qq6/XfGyDXfP2lvyrp/1d.4pGCwI.e6FkeDjTbDM1qUDUxVqR0ORO', 'vimbainashemhangwa@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tblaorder`
--

DROP TABLE IF EXISTS `tblaorder`;
CREATE TABLE IF NOT EXISTS `tblaorder` (
  `orderID` int(11) NOT NULL AUTO_INCREMENT,
  `userID` int(11) NOT NULL,
  `adminID` int(11) NOT NULL,
  `sellerID` int(11) NOT NULL,
  `orderDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `orderStatus` varchar(50) DEFAULT NULL,
  `totalAmount` decimal(10,2) NOT NULL,
  `shippingAddress` varchar(255) NOT NULL,
  PRIMARY KEY (`orderID`),
  KEY `userID` (`userID`),
  KEY `adminID` (`adminID`),
  KEY `sellerID` (`sellerID`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=hp8;

--
-- Dumping data for table `tblaorder`
--

INSERT INTO `tblaorder` (`orderID`, `userID`, `adminID`, `sellerID`, `orderDate`, `orderStatus`, `totalAmount`, `shippingAddress`) VALUES
(1, 2, 1, 1, '2024-09-25 08:30:00', 'Shipped', '350.50', '123 Elm St Springfield'),
(2, 4, 2, 1, '2024-09-26 12:15:00', 'Pending', '120.75', '456 Oak St Maple City'),
(3, 1, 1, 2, '2024-09-27 09:40:00', 'Delivered', '180.00', '789 Pine St River Town'),
(4, 3, 2, 2, '2024-09-28 07:25:00', 'Canceled', '250.00', '101 Maple St Forest Hill'),
(5, 2, 3, 1, '2024-09-29 14:50:00', 'Shipped', '400.00', '202 Birch St Seaside'),
(6, 5, 1, 2, '2024-09-30 10:00:00', 'Delivered', '325.00', '345 Cedar St Mountain View'),
(7, 6, 2, 1, '2024-10-01 07:10:00', 'Pending', '290.75', '789 Walnut St Hilltop'),
(8, 7, 1, 1, '2024-10-02 13:20:00', 'Shipped', '210.50', '123 Oak St Springfield'),
(9, 8, 3, 2, '2024-10-03 11:45:00', 'Canceled', '450.00', '456 Pine St River Town'),
(10, 9, 2, 2, '2024-10-04 08:05:00', 'Delivered', '375.25', '789 Birch St Forest Hill'),
(11, 10, 1, 1, '2024-10-05 12:30:00', 'Shipped', '500.00', '345 Maple St Seaside'),
(12, 11, 2, 2, '2024-10-06 06:40:00', 'Pending', '150.75', '789 Elm St Springfield'),
(13, 12, 3, 1, '2024-10-07 15:55:00', 'Delivered', '220.00', '202 Oak St Maple City'),
(14, 13, 1, 1, '2024-10-08 09:35:00', 'Canceled', '320.50', '123 Pine St River Town'),
(15, 14, 2, 3, '2024-10-09 14:25:00', 'Shipped', '280.00', '456 Birch St Forest Hill'),
(16, 15, 3, 2, '2024-10-10 07:50:00', 'Pending', '450.75', '789 Cedar St Mountain View'),
(17, 16, 1, 3, '2024-10-11 10:15:00', 'Delivered', '180.25', '123 Walnut St Hilltop'),
(18, 17, 2, 1, '2024-10-12 13:30:00', 'Shipped', '360.00', '345 Oak St Seaside'),
(19, 18, 3, 3, '2024-10-13 08:55:00', 'Canceled', '500.50', '789 Maple St Forest Hill'),
(20, 19, 1, 1, '2024-10-14 11:20:00', 'Pending', '425.00', '123 Birch St Springfield'),
(21, 20, 2, 2, '2024-10-15 06:45:00', 'Shipped', '240.25', '202 Elm St Maple City'),
(22, 21, 3, 1, '2024-10-16 15:10:00', 'Delivered', '390.75', '456 Pine St River Town'),
(23, 22, 1, 3, '2024-10-17 09:55:00', 'Canceled', '275.50', '345 Cedar St Forest Hill'),
(24, 23, 2, 2, '2024-10-18 12:35:00', 'Shipped', '420.00', '789 Walnut St Seaside'),
(25, 24, 3, 1, '2024-10-19 07:00:00', 'Pending', '310.75', '123 Maple St Springfield'),
(26, 25, 1, 2, '2024-10-20 14:50:00', 'Delivered', '360.00', '202 Oak St Mountain View'),
(27, 26, 2, 3, '2024-10-21 10:10:00', 'Canceled', '490.50', '456 Birch St Hilltop'),
(28, 27, 3, 2, '2024-10-22 13:40:00', 'Shipped', '245.00', '789 Elm St River Town'),
(29, 28, 1, 1, '2024-10-23 08:05:00', 'Delivered', '385.25', '345 Pine St Seaside'),
(30, 29, 2, 3, '2024-10-24 15:25:00', 'Pending', '330.00', '202 Cedar St Forest Hill');

-- --------------------------------------------------------

--
-- Table structure for table `tblclothes`
--

DROP TABLE IF EXISTS `tblclothes`;
CREATE TABLE IF NOT EXISTS `tblclothes` (
  `clothes_id` int(11) NOT NULL AUTO_INCREMENT,
  `clothes_name` varchar(100) NOT NULL,
  `clothes_description` text,
  `price` decimal(10,2) NOT NULL,
  `size` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `stock_quantity` int(11) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `category` varchar(50) DEFAULT NULL,
  `clothes_condition` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`clothes_id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=hp8;

--
-- Dumping data for table `tblclothes`
--

INSERT INTO `tblclothes` (`clothes_id`, `clothes_name`, `clothes_description`, `price`, `size`, `color`, `stock_quantity`, `image_path`, `category`, `clothes_condition`) VALUES
(1, 'Mens Shorts', 'A stylish brand name short', '120.00', 'M', 'khakhi', 10, '_images/mens_shorts.webp', 'Men', 'New'),
(2, 'Comfortable designer sneakers', 'Womens Platform Sneakers, Casual Lace Up Outdoor Shoes, Comfortable Low Top Sport Shoes', '360.00', '7', 'White', 6, '_images/womens_sneakers.webp', 'Women', 'Like New'),
(3, 'Handbag', 'Elegant crocodile handbag for every occasion', '250.00', 'One Size', 'Brown', 5, '_images/crocodile_handbag.webp', 'Women', 'Good'),
(4, 'Womens Jacket', 'Jil Sander Uniqlo Wool Light Brown Multipocket Womens Coat', '435.00', 'M', 'Grey', 4, '_images/jacket.webp', 'Women', 'New'),
(5, 'Comfortable designer Cap', 'Vintage Gucci Monogram Brown Cap Hat', '259.00', 'One Size', 'Brown', 15, '_images/gucci_cap.webp', 'Men', 'Like New'),
(6, 'Comfortable Wendy Woo sandals', 'Womens Rhinestone Butterfly Flat Sandals, Boho Style Open Toe Elastic Strap Summer Shoes', '360.00', '7', 'Green,White,Pink,Red,Black', 12, '_images/womens_sandals.webp', 'Women', 'Like New'),
(7, 'Cute Kids Dress', 'Solid Color Belted Long Sleeve Peplum Top + Ribbed Pants', '50.00', 'S', 'Green, Brown, Black', 20, '_images/childrens_dress.webp', 'Children', 'Used - Average'),
(8, 'Cute Toddlers T-shirt and Short', 'Celebrity Cartoon Print Girls 2PCS Short Sleeve Top + 3D Graphic Shorts Set, Casual Holiday Summer Outfit', '156.00', 'S', 'Pink', 25, '_images/kids_tshirt.webp', 'Children', 'New'),
(9, 'Womens Swim Wear', 'Jil Sander Swim Wear', '68.75', 'S', 'Grey', 4, '_images/womens_swimwear.webp', 'Women', 'Like New'),
(10, 'Mens Underwear', '5pcs Mens Ice Silk Cool Boxer Briefs', '49.00', 'M', 'Yellow', 7, '_images/mens_underwear.webp', 'Men', 'Good'),
(11, 'Classic Body Con Dress', 'Elegant Body Con Dress Set', '89.76', 'M', 'Red', 3, '_images/womens_dress.webp', 'Women', 'Used - Excellent'),
(12, 'Womens Comfy Panties', '4pcs Colorblock Cute Print Briefs', '20.00', 'M', 'Lake Blue', 18, '_images/womens_underwear.webp', 'Women', 'New'),
(13, 'Boys 3D Hoody', 'Boys Stylish 3D Print Casual Pullover', '203.00', 'M', 'Blue', 8, '_images/boys_hoody.webp', 'Children', 'New'),
(14, 'Mens Formal Shirt', 'Mens Shirt Top Turn-Down Collar Long Sleeve Closure', '212.00', 'M', 'Blue', 6, '_images/mens_formal_shirt.webp', 'Men', 'Good'),
(15, 'Womens Formal Wear', 'Womens Elegant Lapel Collar Long Sleeve Blazer and Pants Suit Set', '368.75', 'M', 'Blue', 2, '_images/womens_suite.webp', 'Women', 'Used - Excellent'),
(16, 'Mens Sil Sleepwear', '2 Pcs Mens Trendy Striped Print Long Sleeve & Trousers Pajama Sets', '121.00', 'M', 'Red', 12, '_images/mens_sleepwear.webp', 'Men', 'Like New'),
(17, 'Super Cute Toddlers Underwear', 'Girls Cute Underwear', '14.00', 'S', 'Pink', 5, '_images/kids_panties.webp', 'Children', 'Good'),
(18, 'Fashion Cartoon Girl Graphic Print', 'Fashion Cartoon Girl Graphic Print, Casual Comfy Round Neck Long Sleeve Sweatshirt For Daily And Outdoor', '124.00', 'M', 'Pink', 3, '_images/childrens_blouse.webp', 'Children', 'Used - Average'),
(19, 'Mens Jean', 'George Mens Regular Fit Jean', '324.00', 'M', 'Blue', 6, '_images/jean.jpeg', 'Men', 'Used - Excellent'),
(20, 'Mens Casual Hoody', 'Mens London England Hoodie', '71.00', 'M', 'Yellow', 9, '_images/mens_hoody.webp', 'Men', 'Average'),
(21, 'Comfortable and warm socks', 'Wear weird-crazy socks for a good cause!', '50.00', 'One Size', 'Brown', 16, '_images/socks.jpeg', 'Children', 'Like New'),
(22, 'Mens Thermal Fuzzy Slides', 'Mens Thermal Fuzzy Slides', '35.00', 'M', 'Yellow', 10, '_images/mens_slippers.webp', 'Men', 'Like New'),
(23, 'Cute Toddlers Sleepwear', 'Boys Casual Underwear Set', '167.00', 'S', 'Grey', 3, '_images/boys_sleepwear.webp', 'Children', 'Used - Average'),
(24, 'MAINALUN Mens Fashion Sneakers', 'Low Top Casual Sports Shoes with solid Color', '60.00', 'M', 'Black', 8, '_images/mens_sneakers.webp', 'Men', 'Like New'),
(25, 'Womens Scarf', 'Casual Comfy Scarf', '90.00', 'One Size', 'Pink', 10, '_images/scarf.jpg', 'Women', 'Used - Average'),
(26, 'Classic Floral Dress', 'Elegant Two-piece Dress Set, Crop Half Sleeve Top & Floral Print Tank Dress Outfits', '632.00', 'M', 'Pink', 13, '_images/trendy_dress.webp', 'womens', 'Used - Excellent'),
(27, 'Comfortable and warm trench coat', 'Mens Winter Fashion Solid Trench Coat, Notch Lapel Buttoned Long Jacket, Classic Design Suitable For Business', '350.00', 'M', 'Brown', 90, '_images/trench_coat.webp', 'mens', 'Like New'),
(28, 'Mens Jacket', 'Mens Zip-up Jacket With Zipper Pockets', '345.00', 'M', 'Blue', 18, '_images/mens_jacket.webp', 'mens', 'Good'),
(29, 'Cute Toddlers Summer Wear', 'Boys Casual Summer Set', '146.00', 'M', 'Red', 12, '_images/kidswear.webp', 'childrens', 'Good'),
(30, 'Mens Denim Shorts', 'A stylish denim short', '115.00', 'M', 'Blue', 46, '_images/mens_denim_shorts.jpeg', 'mens', 'Good');

-- --------------------------------------------------------

--
-- Table structure for table `tblseller`
--

DROP TABLE IF EXISTS `tblseller`;
CREATE TABLE IF NOT EXISTS `tblseller` (
  `sellerID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `status` enum('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  PRIMARY KEY (`sellerID`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=hp8;

--
-- Dumping data for table `tblseller`
--

INSERT INTO `tblseller` (`sellerID`, `name`, `username`, `password`, `email`, `status`) VALUES
(1, 'Alex Johnson', 'ajohnson', '$2y$10$Fw.ePQ7uFIJEWb7L96/hIuXcP5eYPHSV5xpF977jNaHK5e2cRhkFK', 'ajohnson@example.com', 'verified'),
(2, 'Mia Taylor', 'mtaylor', '$2y$10$v2jCudcDAhzqbFLm98nbT.cYgn7iwoAv4xdhmvgAoTczUO/p1vxWy', 'mtaylor@mail.com', 'rejected'),
(3, 'Ethan Brown', 'ebrown', '$2y$10$PQVbqBxsVgI00vShDK4vE.9xPpslmoa7pf2kfuvblb65c6JbbN0WC', 'ebrown@webmail.com', 'verified'),
(4, 'Ava Davis', 'adavis', '$2y$10$QnPp9Sbv.baitPfeeHUPlOvEpr3YQCDO9t4hJ6SahSi/feaUkT3Wi', 'adavis@domain.com', 'pending'),
(5, 'Liam Wilson', 'lwilson', '$2y$10$N7UpSMCt7.G/54OW8OMCseIgF.KiuyaAZnqdHsW/T1vfoFzsxr88S', 'lwilson@service.com', 'verified'),
(6, 'Sophia Martinez', 'smartinez', '$2y$10$czgUHPHYHRkvQKEvC92UqerYmPSAhnBhLdrzY7Fvt/cC8yq4uNcEW', 'smartinez@site.com', 'verified'),
(7, 'Noah Garcia', 'ngarcia', '$2y$10$jexZOAsDts30/FpgbsGFa.Za0Cg1w/LCyRwqCZq8CiPHTTNXdoqfm', 'ngarcia@web.com', 'pending'),
(8, 'Isabella White', 'iwhite', '$2y$10$MyLdUJRZuSploPMeLkG7V.s.LTppLcsfoz3dP.n9aYwYkm.nf1F8S', 'iwhite@domain.com', 'rejected'),
(9, 'James Lee', 'jlee', '$2y$10$fW42QW55io/mn4SN9nvwJeIcz4W3KHbrhhEZYV50D06iA0AbEb2v6', 'jlee@example.com', 'verified'),
(10, 'Olivia Clark', 'oclark', '$2y$10$ih1zwbnKak9R12UpOTkd9ed8ooMJFH5FcuxFFweF8ZucZl9dqi0J.', 'oclark@mail.com', 'verified'),
(11, 'Benjamin Young', 'byoung', '$2y$10$4p.ejwUTCCxAh8csLZ0qIeOUp4hShDJGa0nBAbNgFihTponn4ZRYy', 'byoung@webmail.com', 'rejected'),
(12, 'Emma Hall', 'ehall', '$2y$10$Ajycqp6uRhjX6AR/3UqR0OVEdY4lRtDPMCLMRYArKfT5YIBO/G2Yy', 'ehall@domain.com', 'pending'),
(13, 'Michael Scott', 'mscott', '$2y$10$Xm5UrFyTbe1llQIsuW7Xeu58CUfAGOFHmna6EdRdu/mzQb1cthus2', 'mscott@example.com', 'verified'),
(14, 'Emily Green', 'egreen', '$2y$10$UzsfJsc1hXqwADyNExidseMKVbOmTJBHyUa.rTP3gCVsMf6sMgIoS', 'egreen@service.com', 'pending'),
(15, 'Lucas King', 'lking', '$2y$10$wlZ8OYKO2ElNHuuMPvW1EucF1o9K.zVN5sJ3WSY/3Vt8d6MXetxi6', 'lking@domain.com', 'verified'),
(16, 'Amelia Harris', 'aharris', '$2y$10$2nubjwgOg21Tn6lpciGAzeinSI.7T8rPZ21A9HliYPBb3ak7htWuS', 'aharris@mail.com', 'rejected'),
(17, 'Mason Wright', 'mwright', '$2y$10$hJj7YbyMGzULrSCVQ2d/qOI3mo/LvO3afdjyw84oLGdZhSycVizEy', 'wright@webmail.com', 'verified'),
(18, 'Charlotte Adams', 'cadams', '$2y$10$WF7riz/acw5VW6SERVV21ep.EPGsO/715DjRsN2oCDOizJPGRQsMK', 'cadams@domain.com', 'pending'),
(19, 'Henry Baker', 'hbaker', '$2y$10$6wj8w68IMftT99KuDwxqn.6WNTXuGjEc2htu/EKXnDtHs5FKcc3h6', 'hbaker@example.com', 'verified'),
(20, 'Grace Turner', 'gturner', '$2y$10$46SIbyOA0ab.ps3RcycY4OgUwXONZEe7wfdpWf4TSXpobWhMKvdQG', 'gturner@service.com', 'pending'),
(21, 'Daniel Mitchell', 'dmitchell', '$2y$10$cH5dzxB.Orl/sl/kO0zT3.xJAu2zffPpd7t.O67RarTRqwVLyX7CW', 'dmitchell@domain.com', 'rejected'),
(22, 'Ella Foster', 'efoster', '$2y$10$ILf3b5znADaDM/Notd/AwOQfLDHU/Rd0260I46kUqzf/eoxDfUSV.', 'efoster@mail.com', 'verified'),
(23, 'Samuel Carter', 'scarter', '$2y$10$4LkoY6Hm8b7d//f/v.1icu6.UQp3AOKMT8qHFVVyy6WFxTjoLVmvm', 'scarter@webmail.com', 'pending'),
(24, 'Lily Evans', 'levans', '$2y$10$vpr76jekIKIq7jyo6bOKretDPYfpCnzrKGeDyRBoeE3iTrCYjcrfa', 'levans@domain.com', 'rejected'),
(25, 'Jack Morgan', 'jmorgan', '$2y$10$aJTyrDgL6lLIpZVmiTy2Ie0v2FlwW9z.7BYNjXnEDYSblJuPFyzH.', 'jmorgan@example.com', 'verified'),
(26, 'Abigail Bell', 'abell', '$2y$10$TwECW0IBoTd0nqAqgxV8euXEOoxIVc9XxLEddO4RnFaucs62Yjdcy', 'abell@mail.com', 'verified'),
(27, 'Alexander Parker', 'aparker', '$2y$10$iTjzsivYPbwPjJRcsjAGFOrnIEap7zayEs2o0tMl6kI4T5k.rPq0m', 'aparker@webmail.com', 'pending'),
(28, 'Victoria Ross', 'vross', '$2y$10$qlW9Cf.ZrrMZcxyc.68zsOJ2wO8ksMRKRIwxEATK1F8AaRoDNO6W2', 'vross@domain.com', 'verified'),
(29, 'Sebastian Hughes', 'shughes', '$2y$10$MbIb5hxK6tBNqciLW6hXa.cRAGY8sGEALbjTmF..TDPzX5MxNiLYS', 'shughes@mail.com', 'pending'),
(30, 'Zoe Edwards', 'zedwards', '$2y$10$oVU6MYjGdxCPyCTFkTuV1u/3JivyTtLNBmYVi4ZcLqMuZEVpGrpI.', 'zedwards@webmail.com', 'verified');

-- --------------------------------------------------------

--
-- Table structure for table `tbluser`
--

DROP TABLE IF EXISTS `tbluser`;
CREATE TABLE IF NOT EXISTS `tbluser` (
  `userID` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` enum('admin','user') NOT NULL DEFAULT 'user',
  `status` enum('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  PRIMARY KEY (`userID`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=hp8;

--
-- Dumping data for table `tbluser`
--

INSERT INTO `tbluser` (`userID`, `name`, `username`, `password`, `email`, `role`, `status`) VALUES
(1, 'Vimbai Mhangwa', 'vimbaimhangwa', '$2y$10$L0WVzaPQlJV67mINXj3GS.0x4oaazTncCmlYTsP.Gf669lmLcdC8S', 'vimbaimhangwa@gmail.com', 'user', 'verified'),
(2, 'Jane Smith', 'janesmith', '$2y$10$nFh/4k3QEb8kw8l3YaaYAekMv3Lj.ZMb7CclX0PMwxADVPqLYU9.a', 'janesmith@yahoo.com', 'user', 'pending'),
(3, 'Robert Brown', 'robertb', '$2y$10$15QaYeDwwVhPjG9Vc1lmAOae8f7OD7oNPjKT9s3E5U9Slui.rFjaq', 'robertb@bing.com', 'user', 'rejected'),
(4, 'Alice Johnson', 'alicej', '$2y$10$Jt9mXXmSqduplOM20nJEKOwhG0y5LC4JzI.s1MlwOt5KC6FUnIhpW', 'alicej@example.com', 'user', 'verified'),
(5, 'Tom White', 'tomwhite', '$2y$10$rbXktekKx8cvISak8KFt8Ojo77REnM0ExJh2Rf2XzpueKUFrqY73W', 'tonwhite@green.com', 'user', 'verified'),
(6, 'Michael Davis', 'michaeld', '$2y$10$XmtsXDfo6pZLJI6Y0HqDU.AWr3K4S9y22VQH4UOuuoTBgB3qrEg16', 'michaeld@yahoo.com', 'user', 'verified'),
(7, 'Sarah Wilson', 'sarahw', '$2y$10$dvkxixs6ExZ9JOBVXQpi4uhbW43PdDDFPFh/sOJsEPq9RgE.IxOu2', 'sarahw@gmail.com', 'user', 'verified'),
(8, 'David Johnson', 'davidj', '$2y$10$deMs.VsdT4FbhNmxl8VYn.GtVv6GeMini0jJSQEQUVN1.jsJIQzMm', 'davidj@outlook.com', 'user', 'verified'),
(9, 'Emily Garcia', 'emilyg', '$2y$10$2taDlun4YftEdgxhoF5bsOIxOjv0QOz4gQJIzEMeVYQiG7wPxnfkC', 'emilyg@gmail.com', 'user', 'verified'),
(10, 'Chris Lee', 'chrisl', '$2y$10$uDoLyW5OiwR9Cs1l7XSxdOf/r.FXDbysQpWum8aUALiOcsqL7TSaW', 'chrisl@live.com', 'user', 'pending'),
(11, 'Jessica Martin', 'jessicam', '$2y$10$rF0kAHSDT1iSAM91xJ/Ck.dO8DaK6RyugCEO3Rcw6O0GoL5jqU8zW', 'jessicam@hotmail.com', 'user', 'verified'),
(12, 'Daniel Thompson', 'danielt', '$2y$10$42JIqRrfwGspRJhLfE3IBO6cVFfcGU4G2veih1ALKOrWBkTfUmUoq', 'danielt@yahoo.com', 'user', 'verified'),
(13, 'Sophia White', 'sophiaw', '$2y$10$1Lcij1sgXjy.U6k3tAJfr.L6y.aT3Gc/qLrRo5nposMKaS3Z0GqJq', 'sophiaw@gmail.com', 'user', 'verified'),
(14, 'James Miller', 'jamesm', '$2y$10$QROjaYGEj577b1I0PS.xCu7/gpxolXO91DbprKDusFgngG9dsxIru', 'jamesm@outlook.com', 'user', 'verified'),
(15, 'Emma Taylor', 'emmat', '$2y$10$L6QOfLtho96dCGbGeQoFAuaA7Z2zUOnudNsM77ntRq/ExQnSp6eKC', 'emmat@gmail.com', 'user', 'verified'),
(16, 'Liam Anderson', 'liama', '$2y$10$avkuiYzuHVMjGjTqV/VHJe8ImRe9Hx45KuN/W3ud.Z2sjU8jc5N16', 'liama@yahoo.com', 'user', 'rejected'),
(17, 'Ava Thomas', 'avath', '$2y$10$S9s/uMhsfRV7.XMdbiQ3yOU0e25KxiV5yJh2sS9cal7zpJwUkixni', 'avath@live.com', 'user', 'pending'),
(18, 'Lucas Jackson', 'lucasj', '$2y$10$.IBp0FICXZF9/PSJ0bceHOpQfbC2iDwm1w4zgzoowwVNwOWzKx07G', 'lucasj@hotmail.com', 'user', 'verified'),
(19, 'Mia Harris', 'miah', '$2y$10$mNu.LifCim1UdLUGbKHnx.ify0ljjFfY3a32T44brBeFkZeZWFL1q', 'miah@gmail.com', 'user', 'verified'),
(20, 'Oliver Clark', 'oliverc', '$2y$10$0eEvdADqdS6B2bKbnc7ds.mS7DhuNXeogNZpkgwGtQCtFOr70nMtu', 'oliverc@yahoo.com', 'user', 'verified'),
(21, 'Isabella Lewis', 'isabellal', '$2y$10$SC.HtIcZkfRd.GBqpZ4OBezK6MuDRptc46RI2Ybnxp3GcbRfhq7z.', 'isabellal@outlook.com', 'user', 'rejected'),
(22, 'Benjamin Walker', 'benjaminw', '$2y$10$bjl7XV5Zf.UaGNuVd4.i/eYg6SypQaZFe3s3/h7LkCLtbcWT92I..', 'benjaminw@gmail.com', 'user', 'verified'),
(23, 'Charlotte Hall', 'charlotteh', '$2y$10$qUJZfttgaEvu4aU5tmdGjujohSbzsxIwJg30XIx/S3Hh60ygNHhKm', 'charlotteh@live.com', 'user', 'verified'),
(24, 'Elijah Young', 'elijahy', '$2y$10$2wdy/ctc7t/plrP6sgY1MOwuab6NkMdCGXSA9XaMYAmXOGm2ziMgm', 'elijahy@gmail.com', 'user', 'verified'),
(25, 'Amelia Allen', 'ameliaa', '$2y$10$M5xtgdJ7wER5/XmeP4Y82.ILCYleIcnaf6Ku7HZfD.1ZdKW5K7wMO', 'ameliaa@yahoo.com', 'user', 'verified'),
(26, 'James King', 'jamesk', '$2y$10$Yq451NofJ1OQltpa7Cno/ujU3KWnrae2Fa8.V3PDDTBp1WlFBHxhC', 'jamesk@hotmail.com', 'user', 'verified'),
(27, 'Harper Wright', 'harperw', '$2y$10$Zf2NoKezYAmCyIeJsoKBaOVxeNCxftAlzJ3tzqFVStr727MheDm7e', 'harperw@gmail.com', 'user', 'pending'),
(28, 'Henry Scott', 'henrys', '$2y$10$HvS/PtqmWE/O.2a0xIvT6ePSfiRJ7rHX9ef0QUzoGozvVZWUN5mLi', 'henrys@outlook.com', 'user', 'verified'),
(29, 'Grace Hill', 'graceh', '$2y$10$yUFlW4H4EfCLrWY8V4nXo.5Taj9GRRJKDHNPT/BRJwq.OJIbcS3k2', 'graceh@yahoo.com', 'user', 'verified'),
(30, 'Daniel Green', 'danielg', '$2y$10$tVwCVj0R56N5AlxtZxPyhOiQl6iugKvtM0klH1ZTcMOea.qL.oKru', 'danielg@hotmail.com', 'user', 'verified');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_item`
--

DROP TABLE IF EXISTS `tbl_item`;
CREATE TABLE IF NOT EXISTS `tbl_item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(255) NOT NULL,
  `item_description` text,
  `price` decimal(10,2) NOT NULL,
  `size` varchar(50) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL,
  `stock_quantity` int(11) NOT NULL,
  `image_path` varchar(255) DEFAULT NULL,
  `category` enum('Men','Women','Children') NOT NULL,
  `clothesCondition` enum('New','Like New','Good','Fair','Poor') NOT NULL,
  PRIMARY KEY (`item_id`)
) ENGINE=MyISAM AUTO_INCREMENT=33 DEFAULT CHARSET=hp8;

--
-- Dumping data for table `tbl_item`
--

INSERT INTO `tbl_item` (`item_id`, `item_name`, `item_description`, `price`, `size`, `color`, `stock_quantity`, `image_path`, `category`, `clothesCondition`) VALUES
(1, 'Mens Shorts', 'A stylish brand name short', '120.00', 'M', 'khakhi', 10, '_images/mens_shorts.webp', 'Men', 'Good'),
(2, 'Comfortable designer sneakers', 'Womens Platform Sneakers, Casual Lace Up Outdoor Shoes, Comfortable Low Top Sport Shoes', '360.00', '7', 'White', 6, '_images/womens_sneakers.webp', 'Women', 'Like New'),
(3, 'Handbag', 'Elegant crocodile handbag for every occasion', '250.00', 'One Size', 'Brown', 5, '_images/crocodile_handbag.webp', 'Women', 'Good'),
(4, 'Womens Jacket', 'Jil Sander Uniqlo Wool Light Brown Multipocket Womens Coat', '435.00', 'M', 'Grey', 4, '_images/jacket.webp', 'Women', 'New'),
(5, 'Comfortable designer Cap', 'Vintage Gucci Monogram Brown Cap Hat', '259.00', 'One Size', 'Brown', 15, '_images/gucci_cap.webp', 'Men', 'Like New'),
(6, 'Comfortable Wendy Woo sandals', 'Womens Rhinestone Butterfly Flat Sandals, Boho Style Open Toe Elastic Strap Summer Shoes', '360.00', '7', 'Green,White,Pink,Red,Black', 12, '_images/womens_sandals.webp', 'Women', 'Like New'),
(7, 'Cute Kids Dress', 'Solid Color Belted Long Sleeve Peplum Top + Ribbed Pants', '50.00', 'S', 'Green, Brown, Black', 20, '_images/childrens_dress.webp', 'Children', 'Good'),
(8, 'Cute Toddlers T-shirt and Short', 'Celebrity Cartoon Print Girls 2PCS Short Sleeve Top + 3D Graphic Shorts Set, Casual Holiday Summer Outfit', '156.00', 'S', 'Pink', 25, '_images/kids_tshirt.webp', 'Children', 'New'),
(9, 'Womens Swim Wear', 'Jil Sander Swim Wear', '68.75', 'S', 'Grey', 4, '_images/womens_swimwear.jpeg', 'Women', 'Like New'),
(10, 'Mens Underwear', '5pcs Mens Ice Silk Cool Boxer Briefs', '49.00', 'M', 'Yellow', 7, '_images/mens_underwear.webp', 'Men', 'Good'),
(11, 'Classic Body Con Dress', 'Elegant Body Con Dress Set', '89.76', 'M', 'Red', 3, '_images/womens_dress.webp', 'Women', 'Fair'),
(12, 'Womens Comfy Panties', '4pcs Colorblock Cute Print Briefs', '20.00', 'M', 'Lake Blue', 18, '_images/womens_underwear.webp', 'Women', 'New'),
(13, 'Boys 3D Hoody', 'Boys Stylish 3D Print Casual Pullover', '203.00', 'M', 'Blue', 8, '_images/boys_hoody.webp', 'Children', 'New'),
(14, 'Mens Formal Shirt', 'Mens Shirt Top Turn-Down Collar Long Sleeve Closure', '212.00', 'M', 'Blue', 6, '_images/mens_formal_shirt.webp', 'Men', 'Good'),
(15, 'Womens Formal Wear', 'Womens Elegant Lapel Collar Long Sleeve Blazer and Pants Suit Set', '368.75', 'M', 'Blue', 2, '_images/womens_suite.webp', 'Women', 'Good'),
(16, 'Mens Sleepwear', '2 Pcs Mens Trendy Striped Print Long Sleeve & Trousers Pajama Sets', '121.00', 'M', 'Red', 12, '_images/mens_sleepwear.webp', 'Men', 'Like New'),
(17, 'Super Cute Toddlers Underwear', 'Girls Cute Underwear', '14.00', 'S', 'Pink', 5, '_images/kids_panties.webp', 'Children', 'Good'),
(18, 'Fashion Cartoon Girl Graphic Print', 'Fashion Cartoon Girl Graphic Print, Casual Comfy Round Neck Long Sleeve Sweatshirt For Daily And Outdoor', '124.00', 'M', 'Pink', 3, '_images/childrens_blouse.webp', 'Children', 'Like New'),
(19, 'Mens Jean', 'George Mens Regular Fit Jean', '324.00', 'M', 'Blue', 6, '_images/jean.jpeg', 'Men', 'New'),
(20, 'Mens Casual Hoody', 'Mens London England Hoodie', '71.00', 'M', 'Yellow', 9, '_images/mens_hoody.webp', 'Men', 'New'),
(21, 'Womens Silky Skirt', 'Silky Smooth Skirt', '100.00', 'M', 'Olive', 17, '_images/womens_skirt.webp', 'Women', 'Good'),
(22, 'Comfortable and warm socks', 'Wear weird-crazy socks for a good cause!', '50.00', 'One Size', 'Brown', 16, '_images/socks.jpeg', 'Children', 'Like New'),
(23, 'Mens Thermal Fuzzy Slides', 'Mens Thermal Fuzzy Slides', '35.00', 'M', 'Yellow', 10, '_images/mens_slippers.webp', 'Men', 'Like New'),
(24, 'Cute Toddlers Sleepwear', 'Boys Casual Underwear Set', '167.00', 'S', 'Grey', 3, '_images/boys_sleepwear.webp', 'Children', 'Good'),
(25, 'MAINALUN Mens Fashion Sneakers', 'Low Top Casual Sports Shoes with solid Color', '60.00', 'M', 'Black', 8, '_images/mens_sneakers.webp', 'Men', 'Like New'),
(26, 'Womens Scarf', 'Casual Comfy Scarf', '90.00', 'One Size', 'Pink', 10, '_images/scarf.jpg', 'Women', 'New'),
(27, 'Classic Floral Dress', 'Elegant Two-piece Dress Set, Crop Half Sleeve Top & Floral Print Tank Dress Outfits', '632.00', 'M', 'Pink', 13, '_images/trendy_dress.webp', 'Women', 'Like New'),
(28, 'Comfortable and warm trench coat', 'Mens Winter Fashion Solid Trench Coat, Notch Lapel Buttoned Long Jacket, Classic Design Suitable For Business', '350.00', 'M', 'Brown', 90, '_images/trench_coat.webp', 'Men', 'Like New'),
(29, 'Mens Jacket', 'Mens Zip-up Jacket With Zipper Pockets', '345.00', 'M', 'Blue', 18, '_images/mens_jacket.webp', 'Men', 'Good'),
(30, 'Cute Toddlers Summer Wear', 'Boys Casual Summer Set', '146.00', 'M', 'Red', 12, '_images/kidswear.webp', 'Children', 'Good');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

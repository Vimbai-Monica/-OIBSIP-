<?php
session_start();
include 'DBConn.php';
include 'auth.php'; // Include the authentication code
checkLogin(); // Check if the user is logged in
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Pastimes is your go-to online store for high-quality branded used clothing, offering top-notch fashion at affordable prices.">
    <meta name="keywords" content="clothing store, online shopping, used clothing, affordable fashion, Pastimes, fashion">
    <meta name="revisit" content="30 days">
    <meta http-equiv="refresh" content="30">
    <meta name="robots" content="noindex, nofollow">
    <title>Pastimes Catalogue Page</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/lightbox.css" media="screen" />
    <script src="javascript/jquery-1.10.2.min.js"></script>
    <script src="javascript/lightbox-2.6.min.js"></script>
    <script src="javascript/modernizr.custom.js"></script>
</head>

<body>
    <header>
        <div class="header-container">
            <div class="logo-container">
                <img src="_images/pastimes_logo.png" alt="Pastimes Logo" width="150">
            </div>

            <div class="search-container">
                <input type="text" placeholder="Search for items..." class="search-bar">
                <button class="search-button">Search</button>
            </div>

            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li class="currentPage">Catalogue</li>
                    <li><a href="cart.php"><img src="_images/cart_icon.jpeg" alt="Cart Icon" width="20"> Cart</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li><a href="user_dashboard.php">Dashboard</a></li>
                    <li><a href="logout.php">Log Out</a></li>
                </ul>
            </nav>
        </div>
    </header>


    <!-- Display logged-in user's name -->
    <?php
    if (isset($_SESSION['name'])) {
        // Display the logged-in message
        echo "<p>User " . htmlspecialchars($_SESSION['name']) . " is logged in.</p>";
    } else {
        // Display a message for users who are not logged in
        echo "<p>Welcome, guest! Please log in to access more features.</p>";
    }
    ?>

    <main>
        <section id="All-picks">
            <h3>Welcome to the Catalogue Page</h3>
            <p>Browse through our collection of items below or view them in a table format.
                <a href="catalogue_table_form.php">Click here to view the catalogue in table format.</a>
            </p>

            <!-- Filter Section with Buttons -->
            <div class="button-container">
                <button class="filter-button active" data-category="all">ALL</button>
                <button class="filter-button" data-category="mens">Men's</button>
                <button class="filter-button" data-category="womens">Women's</button>
                <button class="filter-button" data-category="childrens">Children's</button>
            </div>

            <div class="product-section">
                <?php
                // Products array with added 'category' key
                $products = [
                    ['image' => '_images/womens_sandals.webp', 'name' => 'Comfortable Wendy Woo sandals ', 'price' => 'R360', 'condition' => 'Like New', 'description' => 'Womens Rhinestone Butterfly Flat Sandals, Boho Style Open Toe Elastic Strap Summer Shoes', 'colors' => ['Green', 'White', 'Pink', 'Red', 'Black'], 'sizes' => ['5', '6', '7', '8', '9', '10'], 'category' => 'womens'],
                    ['image' => '_images/childrens_dress.webp', 'name' => 'Cute Kids Dress', 'price' => 'R50', 'condition' => 'Used - Average', 'description' => 'Solid Color Belted Long Sleeve Peplum Top + Ribbed Pants', 'colors' => ['Green', 'Brown', 'Black', 'Grey', 'Red', 'Blue', 'Black', 'White'], 'sizes' => ['XXS', 'XS', 'S', 'M', 'L'], 'category' => 'childrens'],
                    ['image' => '_images/mens_shorts.webp', 'name' => 'Mens Shorts', 'price' => 'R120', 'condition' => 'Used - Excellent', 'description' => 'A stylish brand name short', 'colors' => ['khakhi', 'Blue', 'Black', 'White'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'mens'],
                    ['image' => '_images/womens_sneakers.webp', 'name' => 'Comfortable designer sneakers ', 'price' => 'R360', 'condition' => 'Like New', 'description' => 'Womens Platform Sneakers, Casual Lace Up Outdoor Shoes, Comfortable Low Top Sport Shoes', 'colors' => ['Black', 'White', 'Pink', 'Red', 'Green'], 'sizes' => ['5', '6', '7', '8', '9', '10'], 'category' => 'womens'],
                    ['image' => '_images/kids_tshirt.webp', 'name' => 'Cute Toddlers T-shirt and Short', 'price' => 'R156', 'condition' => 'New', 'description' => 'Celebrity Cartoon Print Girls 2PCS Short Sleeve Top + 3D Graphic Shorts Set, Casual Holiday Summer Outfit ', 'colors' => ['Pink', 'Brown', 'Black', 'Grey', 'Red', 'Blue', 'Black', 'White'], 'sizes' => ['XXS', 'XS', 'S', 'M', 'L'], 'category' => 'childrens'],
                    ['image' => '_images/crocodile_handbag.webp', 'name' => 'Handbag', 'price' => 'R250', 'condition' => 'Used - Good', 'description' => 'Elegant crocodile handbag for every occasion ', 'colors' => ['Brown', 'Black', 'khakhi', 'Blue', 'Black', 'White'], 'sizes' => ['One Size'], 'category' => 'womens'],
                    ['image' => '_images/womens_swimwear.jpeg', 'name' => 'Swim Wear', 'price' => 'R68.75', 'condition' => 'Used - Excellent', 'description' => 'Jil Sander Swim Wear', 'colors' => ['Grey', 'Red', 'Blue', 'Black', 'White'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'womens'],
                    ['image' => '_images/mens_underwear.webp', 'name' => 'Mens Underwear', 'price' => 'R49', 'condition' => 'Good', 'description' => '5pcs Mens Ice Silk Cool Boxer Briefs', 'colors' => ['Yellow', 'Blue', 'Black', 'White'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'mens'],
                    ['image' => '_images/jacket.webp', 'name' => 'Womens Jacket', 'price' => 'R435', 'condition' => 'Used - Excellent', 'description' => 'Jil Sander Uniqlo Wool Light Brown Multipocket Womens Coat', 'colors' => ['Grey', 'Red', 'Blue', 'Black', 'White'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'womens'],
                    ['image' => '_images/womens_dress.webp', 'name' => 'Classic Body Con Dress', 'price' => 'R89.76', 'condition' => 'Used - Excellent', 'description' => 'Elegant Body Con Dress Set', 'colors' => ['Red', 'Pink', 'Blue', 'Grey', 'Black'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'womens'],
                    ['image' => '_images/gucci_cap.webp', 'name' => 'Comfortable designer Cap ', 'price' => 'R259', 'condition' => 'Like New', 'description' => 'Vintage Gucci Monogram Brown Cap Hat', 'colors' => ['Brown', 'Black', 'White'], 'sizes' => ['One Size'], 'category' => 'mens'],
                    ['image' => '_images/womens_underwear.webp', 'name' => 'Womens Comfy Panties', 'price' => 'R20', 'condition' => 'New', 'description' => '4pcs Colorblock Cute Print Briefs', 'colors' => ['Lake Blue', 'Brown', 'Black', 'Grey', 'Red', 'Pink', 'Black', 'White'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'womens'],
                    ['image' => '_images/boys_hoody.webp', 'name' => 'Boys 3D Hoody', 'price' => 'R203', 'condition' => 'New', 'description' => 'Boys Stylish 3D Print Casual Pullover', 'colors' => ['Blue', 'Brown', 'Black', 'Grey', 'Red', 'Green', 'Black', 'White'], 'sizes' => ['XXS', 'XS', 'S', 'M', 'L'], 'category' => 'childrens'],
                    ['image' => '_images/mens_formal_shirt.webp', 'name' => 'Mens Formal Shirt', 'price' => 'R212', 'condition' => 'Good', 'description' => 'Mens Shirt Top Turn-Down Collar Long Sleeve Closure', 'colors' => ['White', 'Blue', 'Black',], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'mens'],
                    ['image' => '_images/womens_suite.webp', 'name' => 'Womens Formal Wear', 'price' => 'R368.75', 'condition' => 'Used - Excellent', 'description' => 'Womens Elegant Lapel Collar Long Sleeve Blazer and Pants Suit Set', 'colors' => ['Blue', 'Black', 'White'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'womens'],
                    ['image' => '_images/mens_sleepwear.webp', 'name' => 'Mens Sil Sleepwear', 'price' => 'R121', 'condition' => 'Like New', 'description' => '2 Pcs Mens Trendy Striped Print Long Sleeve & Trousers Pajama Sets', 'colors' => ['Red', 'Yellow', 'Blue', 'Black', 'White'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'mens'],
                    ['image' => '_images/kids_panties.webp', 'name' => 'Super Cute Toddlers Underwear', 'price' => 'R14', 'condition' => 'Good', 'description' => 'Girls Cute  Underwear ', 'colors' => ['Pink', 'Brown', 'Black', 'Grey', 'Blue', 'Black', 'White'], 'sizes' => ['XXS', 'XS', 'S', 'M', 'L'], 'category' => 'childrens'],
                    ['image' => '_images/childrens_blouse.webp', 'name' => 'Fashion Cartoon Girl Graphic Print', 'price' => 'R124', 'condition' => 'Used - Average', 'description' => 'Fashion Cartoon Girl Graphic Print,Casual Comfy Round Neck Long Sleeve Sweatshirt For Daily And Outdoor ', 'colors' => ['Pink', 'Brown', 'Black', 'Grey', 'Red', 'Blue', 'Black', 'White'], 'sizes' => ['XXS', 'XS', 'S', 'M', 'L'], 'category' => 'childrens'],
                    ['image' => '_images/jean.jpeg', 'name' => 'Mens Jean', 'price' => 'R324', 'condition' => 'Used - Excellent', 'description' => 'George Mens Regular Fit Jean', 'colors' => ['Blue', 'Grey', 'Black'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'mens'],
                    ['image' => '_images/mens_hoody.webp', 'name' => 'Mens Casual Hoody', 'price' => 'R71', 'condition' => 'Average', 'description' => 'Mens London England Hoodie', 'colors' => ['Yellow', 'Blue', 'Black', 'White'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'mens'],
                    ['image' => '_images/socks.jpeg', 'name' => 'Comfortable and warm socks. ', 'price' => 'R50', 'condition' => 'Like New', 'description' => 'Wear weird-crazy socks for a good cause !', 'colors' => ['Brown', 'Black', 'White', 'Multi-colored'], 'sizes' => ['One Size'], 'category' => 'childrens'],
                    ['image' => '_images/mens_slippers.webp', 'name' => ' Mens Thermal Fuzzy Slides ', 'price' => 'R35', 'condition' => 'Like New', 'description' => ' Mens Thermal Fuzzy Slides', 'colors' => ['Yellow', 'White', 'Pink', 'Red', 'Black'], 'sizes' => ['5', '6', '7', '8', '9', '10'], 'category' => 'mens'],
                    ['image' => '_images/boys_sleepwear.webp', 'name' => 'Cute Toddlers Sleepwear', 'price' => 'R167', 'condition' => 'Used - Average', 'description' => 'Boys Casual Underwear Set ', 'colors' => ['Grey', 'Brown', 'Black', 'Grey', 'Red', 'Blue', 'Black', 'White'], 'sizes' => ['XXS', 'XS', 'S', 'M', 'L'], 'category' => 'childrens'],
                    ['image' => '_images/mens_sneakers.webp', 'name' => 'MAINALUN Mens Fashion Sneakers ', 'price' => 'R60', 'condition' => 'Like New', 'description' => ' Low Top Casual Sports Shoes with solid Color', 'colors' => ['Black', 'White', 'Pink', 'Red', 'Green'], 'sizes' => ['5', '6', '7', '8', '9', '10'], 'category' => 'mens'],
                    ['image' => '_images/scarf.jpg', 'name' => 'Womens Scarf', 'price' => 'R90', 'condition' => 'Used - Average', 'description' => 'Casual Comfy Scarf ', 'colors' => ['Pink', 'Brown', 'Black', 'Grey', 'Red', 'Blue', 'Black', 'White'], 'sizes' => ['One Size'], 'category' => 'womens'],
                    ['image' => '_images/trendy_dress.webp', 'name' => 'Classic Floral Dress', 'price' => 'R632', 'condition' => 'Used - Excellent', 'description' => 'Elegant Two-piece Dress Set, Crop Half Sleeve Top & Floral Print Tank Dress Outfits', 'colors' => ['Pink', 'Blue', 'Grey', 'Black'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'womens'],
                    ['image' => '_images/trench_coat.webp', 'name' => 'Comfortable and warm trench coat. ', 'price' => 'R350', 'condition' => 'Like New', 'description' => 'Mens Winter Fashion Solid Trench Coat, Notch Lapel Buttoned Long Jacket, Classic Design Suitable For Business', 'colors' => ['Brown', 'Black', 'White', 'Multi-colored'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'mens'],
                    ['image' => '_images/mens_jacket.webp', 'name' => 'Mens Jacket', 'price' => 'R345', 'condition' => 'Good', 'description' => 'Mens Zip-up Jacket With Zipper Pockets', 'colors' => ['Blue', 'Black', 'White'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'mens'],
                    ['image' => '_images/kidswear.webp', 'name' => 'Cute Toddlers Summer Wear', 'price' => 'R146', 'condition' => 'Good', 'description' => 'Boys Casual Summer Set ', 'colors' => ['Red', 'Brown', 'Black', 'Grey', 'Blue', 'Black', 'White'], 'sizes' => ['XXS', 'XS', 'S', 'M', 'L'], 'category' => 'childrens'],
                    ['image' => '_images/mens_denim_shorts.jpeg', 'name' => 'Mens Denim Shorts', 'price' => 'R115', 'condition' => 'Good', 'description' => 'A stylish denim short', 'colors' => ['Blue', 'Black', 'White'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'mens'],
                    ['image' => '_images/womens_gown.webp', 'name' => 'Womens Contrast Gown', 'price' => 'R100', 'condition' => 'Used - Average', 'description' => 'Contrast Lace Set, Semi Sheer Long Sleeve Robe With Belt', 'colors' => ['Lake Blue', 'Brown', 'Black', 'Grey', 'Red', 'Pink', 'Black', 'White'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'womens'],
                    ['image' => '_images/womens_skirt.webp', 'name' => 'Womens Silky Skirt', 'price' => 'R100', 'condition' => 'Average', 'description' => 'Silky Smooth Skirt', 'colors' => ['Olive', 'Brown', 'Black', 'Grey', 'Red', 'Pink', 'Black', 'White'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'womens'],

                ];

                foreach ($products as $product) {
                    echo "
                    <div class='product-item category-{$product['category']}'>
                        <a href='{$product['image']}' data-lightbox='product-gallery' data-title='{$product['name']}'>
                            <img src='{$product['image']}' alt='{$product['name']}' class='product-image'>
                        </a>
                        <p class='product-name'>{$product['name']}</p>
                        <p class='product-price'>{$product['price']}</p>
                        <p class='product-condition'>Condition: {$product['condition']}</p>
                        <p class='product-description'>{$product['description']}</p>
            
                        <!-- Color Selection -->
                        <label for='color-select-{$product['name']}'>Choose a color:</label>
                        <select name='color' id='color-select-{$product['name']}'>";
                    foreach ($product['colors'] as $color) {
                        echo "<option value='$color'>$color</option>";
                    }
                    echo "</select><br>";

                    // Size Selection
                    echo "<label for='size-select-{$product['name']}'>Choose a size:</label>
                        <select name='size' id='size-select-{$product['name']}'>";
                    foreach ($product['sizes'] as $size) {
                        echo "<option value='$size'>$size</option>";
                    }
                    echo "</select>
                        
                    <!-- Buttons -->
                        <button class='add-to-cart' onclick=\"addToCart('{$product['name']}')\">Add to Cart</button>
                        <button class='add-to-wishlist' onclick=\"addToWishlist('{$product['name']}')\">Add to Wishlist</button>
                        <button class='show-cart' onclick=\"showcart()\">Show Cart</button>
                   
                    </div>"; // Close product-item div
                }
                ?>

            </div>

            <script>
                // Function to add an item to the cart and show a success message
                function addToCart(productName) {
                    // Retrieve the cart from sessionStorage (if it exists)
                    let cart = JSON.parse(sessionStorage.getItem('cart')) || [];

                    // Add the product to the cart
                    cart.push(productName);

                    // Save the updated cart back to sessionStorage
                    sessionStorage.setItem('cart', JSON.stringify(cart));

                    // Show the success message
                    alert(productName + " has been successfully added to the cart.");
                }


                // Simple JavaScript function to add the item to the wishlist
                function addToWishlist(productName) {
                    // Example: You could use AJAX or save to session/local storage
                    alert(productName + " has been added to your wishlist.");
                }

                // Function to redirect to the cart page
                function showcart() {
                    window.location.href = 'cart.php'; // Redirect to the cart page
                }
            </script>
        </section>


        <script>
            // Filtering logic with buttons
            const filterButtons = document.querySelectorAll('.filter-button');
            const productItems = document.querySelectorAll('.product-item');

            filterButtons.forEach(button => {
                button.addEventListener('click', () => {
                    const category = button.getAttribute('data-category');

                    // Remove active class from all buttons
                    filterButtons.forEach(btn => btn.classList.remove('active'));
                    // Add active class to the clicked button
                    button.classList.add('active');

                    // Show/hide product items based on category
                    productItems.forEach(item => {
                        if (category === 'all' || item.classList.contains('category-' + category)) {
                            item.style.display = 'block';
                        } else {
                            item.style.display = 'none';
                        }
                    });
                });
            });
        </script>

        <a href="catalogue_table_form.php">Click here to view the catalogue in table format.</a>

    </main>

    <footer>
        <!-- Menu -->
        <div id="footer-menu" class="footer-section">
            <!-- Bottom Navigation Menu -->

            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li class="currentPage">Catalogue</li>
                    <li><a href="cart.php"><img src="_images/cart_icon.jpeg" alt="Cart Icon" width="20"> Cart</a></li>
                    <li><a href="user_dashboard.php">Dashboard</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                </ul>
            </nav>
        </div>


        <div id="footer-content">
            <!-- Lets Connect -->
            <div id="social-media-footer" class="footer-section">
                <h4>Lets Connect</h4>
                <div>
                    <a href="https://www.instagram.com/moni_que360" target="_blank">
                        <img src="_images/instagram_icon.jpg" alt="Instagram Icon" width="3%"> @moni_que360</a>
                </div>
                <div>
                    <a href="https://www.facebook.com/profile.php?id=61557561089299" target="_blank">
                        <img src="_images/facebook_icon.jpg" alt="Facebook Icon" width="3%"> Facebook</a>
                </div>
                <!-- Email -->
                <div>
                    <p><a href="mailto:pastimes23@gmail.com">pastimes23@gmail.com</a></p>
                </div>
            </div>
            <!-- Contact Information -->
            <div id="contact-info-footer-left" class="footer-section">
                <!-- Address -->
                <div class="address">
                    <h4><u>Address</u></h4>
                    <p><img src="_images/location_icon.jpg" alt="Address Icon" width="5%"> 19 Lyster Crescent, <br>
                        Randpark Ridge, <br>
                        Randburg, Johannesburg, 2169</p>
                </div>
                <!-- Working Hours -->
                <div class="working-hours">
                    <h4><u>Working hours:</u></h4>
                    <p class="no-break">Monday to Saturday: Open 24 hours</p>
                    <p class="no-break">Sunday: Closed</p>
                </div>
            </div>
        </div>
    </footer>

</body>

</html>
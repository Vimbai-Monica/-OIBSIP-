<?php
session_start();

// Include database connection
include 'DBConn.php';  // This should set the $dbConnection variable correctly

if (isset($_POST['approve']) || isset($_POST['reject'])) {
    $requestID = $_POST['requestID'];
    $status = isset($_POST['approve']) ? 'approved' : 'rejected';

    // Update the request status in seller_requests table
    $updateQuery = "UPDATE seller_requests SET status = ?, adminResponseDate = NOW() WHERE requestID = ?";
    
    // Prepare statement using $dbConnection
    if ($stmt = $dbConnection->prepare($updateQuery)) {
        // Bind parameters
        $stmt->bind_param("si", $status, $requestID);
        
        // Execute the query
        if ($stmt->execute()) {
            // If the request was approved, update the user's role in users table
            if ($status == 'approved') {
                $userQuery = "UPDATE users SET role = 'seller' WHERE userID = 
                            (SELECT userID FROM seller_requests WHERE requestID = ?)";

                // Prepare and execute the second query to update user role
                if ($userStmt = $dbConnection->prepare($userQuery)) {
                    $userStmt->bind_param("i", $requestID);
                    if ($userStmt->execute()) {
                        // Successfully updated the user's role to 'seller'
                    } else {
                        echo "Error executing user update query: " . $dbConnection->error;
                    }
                    $userStmt->close(); // Close user statement
                } else {
                    // Print error if the second query preparation fails
                    echo "Error preparing user update query: " . $dbConnection->error;
                }
            }

            // Close the first statement (for seller_requests update)
            $stmt->close();

            // Redirect to admin dashboard after processing
            header("Location: admin_management.php");
            exit();
        } else {
            // Print error if the seller_requests query execution fails
            echo "Error executing query: " . $dbConnection->error;
        }
    } else {
        // Print error if the seller_requests query preparation fails
        echo "Error preparing query: " . $dbConnection->error;
    }
}
?>

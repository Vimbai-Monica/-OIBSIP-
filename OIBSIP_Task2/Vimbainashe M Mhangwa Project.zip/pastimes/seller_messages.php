<?php
session_start();

// Include database connection
include 'DBConn.php';
?>

<h2>Your Messages</h2>

<div id="Messages">
    <?php
    // Fetch unread messages for the user
    $messageQuery = "SELECT message, timestamp FROM admin_messages 
                     WHERE recipientID = ? AND status = 'unread' 
                     ORDER BY timestamp DESC";
    $stmt = $dbConnection->prepare($messageQuery);

    if ($stmt) {
        $stmt->bind_param("i", $userID);
        $stmt->execute();
        $messageResult = $stmt->get_result();

        // Check if there are any messages
        if ($messageResult->num_rows > 0) {
            // Display each message
            while ($messageRow = $messageResult->fetch_assoc()) {
                echo "<p><strong>Message:</strong> " . htmlentities($messageRow['message']) . "</p>";
                echo "<p><em>Received on:</em> " . $messageRow['timestamp'] . "</p><hr>";
            }

            // Mark messages as read
            $updateStatusQuery = "UPDATE admin_messages SET status = 'read' WHERE recipientID = ? AND status = 'unread'";
            $updateStmt = $dbConnection->prepare($updateStatusQuery);
            $updateStmt->bind_param("i", $userID);
            $updateStmt->execute();
        } else {
            echo "<p>No new messages.</p>";
        }

        $stmt->close();
    } else {
        echo "<p>Error fetching messages.</p>";
    }
    ?>
</div>

<a href="seller_dashboard.php" class="button">Back to Seller Dashboard</a>

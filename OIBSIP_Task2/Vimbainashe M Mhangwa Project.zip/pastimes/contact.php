<?php
session_start();
include 'DBConn.php';
include 'auth.php'; // Include the authentication code
checkLogin(); // Check if the user is logged in
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Pastimes is your go-to online store for high-quality branded used clothing, offering top-notch fashion at affordable prices.">
    <meta name="keywords" content="clothing store, online shopping, used clothing, affordable fashion, Pastimes, fashion">
    <meta name="revisit" content="30 days">
    <meta http-equiv="refresh" content="30">
    <meta name="robots" content="noindex, nofollow">
    <title>Pastimes Contact Us </title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body>
    <header>
        <div class="header-container">
            <div class="logo-container">
                <img src="_images/pastimes_logo.png" alt="Pastimes Logo" width="150">
            </div>

            <div class="search-container">
                <input type="text" placeholder="Search for items..." class="search-bar" id="search-input">
                <button class="search-button" id="search-button">Search</button>
            </div>
            <script>
                document.getElementById('search-button').addEventListener('click', function() {
                    const query = document.getElementById('search-input').value;
                    if (query) {
                        // Perform the search action here. For example, you can redirect to a search results page:
                        alert('Searching for: ' + query); // Replace this line with your search functionality
                        // window.location.href = 'search-results.html?query=' + encodeURIComponent(query);
                    } else {
                        alert('Please enter a search term.');
                    }
                });

                // Optional: Enable searching by pressing Enter in the input field
                document.getElementById('search-input').addEventListener('keypress', function(event) {
                    if (event.key === 'Enter') {
                        document.getElementById('search-button').click();
                    }
                });
            </script>

            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="catalogue.php">Catalogue</a></li>
                    <li><a href="cart.php"><img src="_images/cart_icon.jpeg" alt="Cart Icon" width="20"> Cart</a></li>
                    <li class="currentPage">Contact Us</li>
                    <li><a href="user_dashboard.php">Dashboard</a></li>
                    <li><a href="logout.php">Log Out</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Display logged-in user's name -->
    <?php
    if (isset($_SESSION['name'])) {
        // Display the logged-in message
        echo "<p>User " . htmlspecialchars($_SESSION['name']) . " is logged in.</p>";
    } else {
        // Display a message for users who are not logged in
        echo "<p>Welcome, guest! Please log in to access more features.</p>";
    }
    ?>

    <main>
        <section id="content">
            <!-- Background image (Google Maps) covering half the page -->
            <div id="google-maps" style="margin: 20px; height: 50vh;">
                <!-- Embed your Google Maps iframe here -->
                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d22195.59371197968!2d27.9317277!3d-26.1025052!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x6782ad0b6e340089!2s19%20Lyster%20Cres,%20Randpark%20Ridge,%20Randburg,%202169!5e0!3m2!1sen!2sza!4v1647775732739!5m2!1sen!2sza"
                    width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </section>

        <!-- Contact Container -->
        <div class="contact-container">
            <!-- Contact Info Section -->
            <div class="contact-info">
                <!-- Address Section -->
                <div>
                    <i class="fa fa-map-marker" style="font-size:24px;color:#00adb5"></i>
                    <span>
                        <h5>Address</h5>
                        19 Lyster Crescent, <br>
                        Randpark Ridge, <br>
                        Randburg, Johannesburg, 2169</p>

                    </span>
                </div>

                <!-- Phone Numbers Section -->
                <div>
                    <i class="fa fa-phone" style="font-size:24px;color:#00adb5"></i>
                    <span>
                        <h5>+27 71 721 0267 / +27 73 902 8540</h5>
                    </span>
                </div>

                <!-- Email Section -->
                <div>
                    <i class="fa fa-envelope" style="font-size:24px;color:#00adb5"></i>
                    <span>
                        <h5>pastimes23@gmail.com</h5>
                        <p>Email us for any queries</p>
                    </span>
                </div>

                <!-- Social Media Section -->
                <div>
                    <i class="fa fa-instagram" style="font-size:24px;color:#00adb5"></i>
                    <span>
                        <h5>Instagram</h5>
                        <a href="https://www.instagram.com/moni_que360" target="_blank">
                            @moni_que360
                        </a>
                    </span>
                </div>

                <div>
                    <i class="fa fa-facebook" style="font-size:24px;color:#00adb5"></i>
                    <span>
                        <h5>Facebook</h5>
                        <a href="https://www.facebook.com/pastime.fb/" target="_blank"> Pastimes
                        </a>
                    </span>
                </div>
            </div>

            <!-- Message Us Section -->
            <div class="contact-form">
                <h2>Message Us</h2>
                <form action="contact.php" method="POST">
                    <label for="name">Name:</label>
                    <input type="text" name="name" id="name" value="<?= isset($_POST['name']) ? htmlspecialchars($_POST['name']) : ''; ?>" required><br>

                    <label for="email">Email:</label>
                    <input type="email" name="email" id="email" value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" required><br>

                    <label for="subject">Subject:</label>
                    <input type="text" name="subject" id="subject" value="<?= isset($_POST['subject']) ? htmlspecialchars($_POST['subject']) : ''; ?>" required><br>

                    <label for="message">Message:</label>
                    <textarea name="message" id="message" required><?= isset($_POST['message']) ? htmlspecialchars($_POST['message']) : ''; ?></textarea><br>

                    <button type="submit" name="submit">Send Message</button>
                </form>
            </div>
        </div>

        <!-- Display Feedback if Submitted -->
        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $name = htmlspecialchars($_POST['name']);
            $email = htmlspecialchars($_POST['email']);
            $subject = htmlspecialchars($_POST['subject']);
            $message = htmlspecialchars($_POST['message']);

            // Simple validation
            if (!empty($name) && !empty($email) && !empty($subject) && !empty($message)) {
                // Send email or save to database (this is a placeholder)
                echo "<div class='success'>Thank you, <strong>$name</strong>. We have received your message.</div>";
            } else {
                echo "<div class='error'>Please fill in all fields correctly.</div>";
            }
        }
        ?>
    </main>

    <footer>
        <!-- Menu -->
        <div id="footer-menu" class="footer-section">
            <!-- Bottom Navigation Menu -->

            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="catalogue.php">Catalogue</a></li>
                    <li><a href="cart.php"><img src="_images/cart_icon.jpeg" alt="Cart Icon" width="20"> Cart</a></li>
                    <li class="currentPage">Contact Us</li>
                    <li><a href="user_dashboard.php">Dashboard</a></li>
            </nav>

        </div>


        <div id="footer-content">
            <!-- Lets Connect -->
            <div id="social-media-footer" class="footer-section">
                <h4>Lets Connect</h4>
                <div>
                    <a href="https://www.instagram.com/moni_que360" target="_blank">
                        <img src="_images/instagram_icon.jpg" alt="Instagram Icon" width="3%"> @moni_que360</a>
                </div>
                <div>
                    <a href="https://www.facebook.com/pastime.fb/" target="_blank">
                        <img src="_images/facebook_icon.jpg" alt="Facebook Icon" width="3%"> Facebook</a>
                </div>
                <!-- Email -->
                <div>
                    <p><a href="mailto:pastimes23@gmail.com">pastimes23@gmail.com</a></p>
                </div>
            </div>
            <!-- Contact Information -->
            <div id="contact-info-footer-left" class="footer-section">
                <!-- Address -->
                <div class="address">
                    <h4><u>Address</u></h4>
                    <p><img src="_images/location_icon.jpg" alt="Address Icon" width="5%"> 19 Lyster Crescent, <br>
                        Randpark Ridge, <br>
                        Randburg, Johannesburg, 2169</p>
                </div>
                <!-- Working Hours -->
                <div class="working-hours">
                    <h4><u>Working hours:</u></h4>
                    <p class="no-break">Monday to Saturday: Open 24 hours</p>
                    <p class="no-break">Sunday: Closed</p>
                </div>
            </div>
        </div>
        <!-- Copyright and Last Modified Date -->
        <p>
            <?php
            echo "&copy; " . date("Y") . " - Pastimes | Last modified: " . date("F d, Y", filemtime(__FILE__));
            ?>
            <br>Powered by "Sustainable Fashion" Solutions
        </p>
        </div>
        </div>
    </footer>

</body>

</html>
<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Pastimes is your go-to online store for high-quality branded used clothing, offering top-notch fashion at affordable prices.">
    <meta name="keywords" content="clothing store, online shopping, used clothing, affordable fashion, Pastimes, fashion">
    <meta name="revisit" content="30 days">
    <meta http-equiv="refresh" content="30">
    <meta name="robots" content="noindex, nofollow">
    <title>Pastimes Homepage </title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/lightbox.css" media="screen" />
    <script src="javascript/jquery-1.10.2.min.js"></script>
    <script src="javascript/lightbox-2.6.min.js"></script>
    <script src="javascript/modernizr.custom.js"></script>

</head>

<body>
    <header>

        <div class="header-container">
            <div class="logo-container">
                <img src="_images/pastimes_logo.png" alt="Pastimes Logo" width="150">
            </div>

            <div class="search-container">
                <input type="text" placeholder="Search for items..." class="search-bar" id="search-input">
                <button class="search-button" id="search-button">Search</button>
            </div>
            <script>
                document.getElementById('search-button').addEventListener('click', function() {
                    const query = document.getElementById('search-input').value;
                    if (query) {
                        // Perform the search action here. For example, you can redirect to a search results page:
                        alert('Searching for: ' + query); // Replace this line with your search functionality
                        // window.location.href = 'search-results.html?query=' + encodeURIComponent(query);
                    } else {
                        alert('Please enter a search term.');
                    }
                });

                // Optional: Enable searching by pressing Enter in the input field
                document.getElementById('search-input').addEventListener('keypress', function(event) {
                    if (event.key === 'Enter') {
                        document.getElementById('search-button').click();
                    }
                });
            </script>

            <nav>
                <ul>
                    <li class="currentPage">Home</li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="catalogue.php">Catalogue</a></li>
                    <li><a href="cart.php"><img src="_images/cart_icon.jpeg" alt="Cart Icon" width="20"> Cart</a></li>
                    <li><a href="signup.php">Sign Up</a></li>
                    <li><a href="user_login.php">Login</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li><a href="admin_login.php">Admin</a></li>
                    <li><a href="user_dashboard.php">Dashboard</a></li>
                    <li><a href="logout.php">Log Out</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">

        <!-- Display logged-in user's name -->
        <?php
        if (isset($_SESSION['name'])) {
            // Display the logged-in message
            echo "<p>User " . htmlspecialchars($_SESSION['name']) . " is logged in.</p>";
        } else {
            // Display a message for users who are not logged in
            echo "<p>Welcome, guest! Please log in to access more features.</p>";
        }
        ?>
    </div>

    <main>
        <section id="hero">
            <div class="hero-text">
                <h2>Welcome to Pastimes</h2>
                <p>Your destination for high-quality branded used clothing. Discover fashion that fits your style at prices you'll love. Our goal is to lead the way in promoting environmentally friendly practices in the fashion industry.</p>
            </div>


            <!-- Featured Section -->
            <section id="featured-products">
                <h3>Featured Products</h3>
                <div class="product-section">
                    <?php
                    $products = [
                        ['image' => '_images/womens_suite.webp', 'name' => 'Womens Formal Wear', 'price' => 'R368.75', 'condition' => 'Used - Excellent', 'description' => 'Womens Elegant Lapel Collar Long Sleeve Blazer and Pants Suit Set', 'colors' => ['Blue', 'Black', 'White'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'womens'],
                        ['image' => '_images/womens_sneakers.webp', 'name' => 'Comfortable designer sneakers ', 'price' => 'R360', 'condition' => 'Like New', 'description' => 'Womens Platform Sneakers, Casual Lace Up Outdoor Shoes, Comfortable Low Top Sport Shoes', 'colors' => ['Black', 'White', 'Pink', 'Red', 'Green'], 'sizes' => ['5', '6', '7', '8', '9', '10']],
                        ['image' => '_images/mens_suite.webp', 'name' => 'Mens Formal Suite', 'price' => 'R550', 'condition' => 'Used - Good', 'description' => '3-Piece Mens Classic Solid Dress Suit Set', 'colors' => ['Blue', 'Black', 'Grey', 'White'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL'], 'category' => 'mens'],
                    ];

                    foreach ($products as $product) {
                        echo "
                    <div class='product-item'>
                        <a href='{$product['image']}' data-lightbox='product-gallery' data-title='{$product['name']}'>
                            <img src='{$product['image']}' alt='{$product['name']}' class='product-image'>
                        </a>
                        <p class='product-name'>{$product['name']}</p>
                        <p class='product-price'>{$product['price']}</p>
                        <p class='product-condition'>Condition: {$product['condition']}</p>
                        <p class='product-description'>{$product['description']}</p>

                        <!-- Color Selection -->
                        <label for='color-select-{$product['name']}'>Choose a color:</label>
                        <select name='color' id='color-select-{$product['name']}'>";
                        foreach ($product['colors'] as $color) {
                            echo "<option value='$color'>$color</option>";
                        }
                        echo "</select><br>";

                        // Size Selection
                        echo "<label for='size-select-{$product['name']}'>Choose a size:</label>
                        <select name='size' id='size-select-{$product['name']}'>";
                        foreach ($product['sizes'] as $size) {
                            echo "<option value='$size'>$size</option>";
                        }
                        echo "</select>

            
                    <!-- Buttons -->
                        <button class='add-to-cart' onclick=\"addToCart('{$product['name']}')\">Add to Cart</button>
                        <button class='add-to-wishlist' onclick=\"addToWishlist('{$product['name']}')\">Add to Wishlist</button>
                        <button class='show-cart' onclick=\"showcart()\">Show Cart</button>
                   
                    </div>"; // Close product-item div
                }
                ?>

            </div>

            <script>
                // Function to add an item to the cart and show a success message
                function addToCart(productName) {
                    // Retrieve the cart from sessionStorage (if it exists)
                    let cart = JSON.parse(sessionStorage.getItem('cart')) || [];

                    // Add the product to the cart
                    cart.push(productName);

                    // Save the updated cart back to sessionStorage
                    sessionStorage.setItem('cart', JSON.stringify(cart));

                    // Show the success message
                    alert(productName + " has been successfully added to the cart.");
                }


                // Simple JavaScript function to add the item to the wishlist
                function addToWishlist(productName) {
                    // Example: You could use AJAX or save to session/local storage
                    alert(productName + " has been added to your wishlist.");
                }

                // Function to redirect to the cart page
                function showcart() {
                    window.location.href = 'cart.php'; // Redirect to the cart page
                }
            </script>
        </section>


            <!-- Newly Listed Section -->
            <section id="newly-listed-products">
                <h3>Newly Listed</h3>
                <div class="product-section">
                    <?php
                    $products = [
                        ['image' => '_images/jacket.webp', 'name' => 'Womens Jacket', 'price' => 'R435', 'condition' => 'Used - Excellent', 'description' => 'Jil Sander Uniqlo Wool Light Brown Multipocket Womens Coat', 'colors' => ['Grey', 'Red', 'Blue', 'Black', 'White'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL']],
                        ['image' => '_images/gucci_cap.webp', 'name' => 'Comfortable designer Cap ', 'price' => 'R259', 'condition' => 'Like New', 'description' => 'Vintage Gucci Monogram Brown Cap Hat', 'colors' => ['Brown', 'Black', 'White'], 'sizes' => ['One Size']],
                        ['image' => '_images/childrens_blouse.webp', 'name' => 'Fashion Cartoon Girl Graphic Print', 'price' => 'R124', 'condition' => 'Used - Average', 'description' => 'Fashion Cartoon Girl Graphic Print,Casual Comfy Round Neck Long Sleeve Sweatshirt For Daily And Outdoor ', 'colors' => ['Pink', 'Brown', 'Black', 'Grey', 'Red', 'Blue', 'Black', 'White'], 'sizes' => ['XXS', 'XS', 'S', 'M', 'L']],
                    ];

                    foreach ($products as $product) {
                        echo "
                    <div class='product-item'>
                        <a href='{$product['image']}' data-lightbox='product-gallery' data-title='{$product['name']}'>
                            <img src='{$product['image']}' alt='{$product['name']}' class='product-image'>
                        </a>
                        <p class='product-name'>{$product['name']}</p>
                        <p class='product-price'>{$product['price']}</p>
                        <p class='product-condition'>Condition: {$product['condition']}</p>
                        <p class='product-description'>{$product['description']}</p>

                        <!-- Color Selection -->
                        <label for='color-select-{$product['name']}'>Choose a color:</label>
                        <select name='color' id='color-select-{$product['name']}'>";
                        foreach ($product['colors'] as $color) {
                            echo "<option value='$color'>$color</option>";
                        }
                        echo "</select><br>";

                        // Size Selection
                        echo "<label for='size-select-{$product['name']}'>Choose a size:</label>
                        <select name='size' id='size-select-{$product['name']}'>";
                        foreach ($product['sizes'] as $size) {
                            echo "<option value='$size'>$size</option>";
                        }
                        echo "</select>

                         
                    <!-- Buttons -->
                        <button class='add-to-cart' onclick=\"addToCart('{$product['name']}')\">Add to Cart</button>
                        <button class='add-to-wishlist' onclick=\"addToWishlist('{$product['name']}')\">Add to Wishlist</button>
                        <button class='show-cart' onclick=\"showcart()\">Show Cart</button>
                   
                    </div>"; // Close product-item div
                }
                ?>

            </div>

            <script>
                // Function to add an item to the cart and show a success message
                function addToCart(productName) {
                    // Retrieve the cart from sessionStorage (if it exists)
                    let cart = JSON.parse(sessionStorage.getItem('cart')) || [];

                    // Add the product to the cart
                    cart.push(productName);

                    // Save the updated cart back to sessionStorage
                    sessionStorage.setItem('cart', JSON.stringify(cart));

                    // Show the success message
                    alert(productName + " has been successfully added to the cart.");
                }


                // Simple JavaScript function to add the item to the wishlist
                function addToWishlist(productName) {
                    // Example: You could use AJAX or save to session/local storage
                    alert(productName + " has been added to your wishlist.");
                }

                // Function to redirect to the cart page
                function showcart() {
                    window.location.href = 'cart.php'; // Redirect to the cart page
                }
            </script>
        </section>

            <!-- Staff Picks Section -->
            <section id="staff-picks">
                <h3>Staff Picks</h3>
                <div class="product-section">
                    <!-- Similar PHP loop can be used to populate staff picks products -->

                    <?php
                    $products = [
                        ['image' => '_images/jean.jpeg', 'name' => 'Mens Jean', 'price' => 'R324', 'condition' => 'Used - Excellent', 'description' => 'George Mens Regular Fit Jean', 'colors' => ['Blue', 'Grey', 'Black'], 'sizes' => ['XS', 'S', 'M', 'L', 'XL', 'XXL']],
                        ['image' => '_images/socks.jpeg', 'name' => 'Comfortable and warm socks. ', 'price' => 'R50', 'condition' => 'Like New', 'description' => 'Wear weird-crazy socks for a good cause !', 'colors' => ['Brown', 'Black', 'White', 'Multi-colored'], 'sizes' => ['One Size']],
                        ['image' => '_images/scarf.jpg', 'name' => 'Womens Scarf', 'price' => 'R90', 'condition' => 'Used - Average', 'description' => 'Casual Comfy Scarf ', 'colors' => ['Pink', 'Brown', 'Black', 'Grey', 'Red', 'Blue', 'Black', 'White'], 'sizes' => ['One Size']],
                    ];

                    foreach ($products as $product) {
                        echo "
                    <div class='product-item'>
                        <a href='{$product['image']}' data-lightbox='product-gallery' data-title='{$product['name']}'>
                            <img src='{$product['image']}' alt='{$product['name']}' class='product-image'>
                        </a>
                        <p class='product-name'>{$product['name']}</p>
                        <p class='product-price'>{$product['price']}</p>
                        <p class='product-condition'>Condition: {$product['condition']}</p>
                        <p class='product-description'>{$product['description']}</p>

                        <!-- Color Selection -->
                        <label for='color-select-{$product['name']}'>Choose a color:</label>
                        <select name='color' id='color-select-{$product['name']}'>";
                        foreach ($product['colors'] as $color) {
                            echo "<option value='$color'>$color</option>";
                        }
                        echo "</select><br>";

                        // Size Selection
                        echo "<label for='size-select-{$product['name']}'>Choose a size:</label>
                        <select name='size' id='size-select-{$product['name']}'>";
                        foreach ($product['sizes'] as $size) {
                            echo "<option value='$size'>$size</option>";
                        }
                        echo "</select>

                   
                    <!-- Buttons -->
                        <button class='add-to-cart' onclick=\"addToCart('{$product['name']}')\">Add to Cart</button>
                        <button class='add-to-wishlist' onclick=\"addToWishlist('{$product['name']}')\">Add to Wishlist</button>
                        <button class='show-cart' onclick=\"showcart()\">Show Cart</button>
                   
                    </div>"; // Close product-item div
                }
                ?>

            </div>

            <script>
                // Function to add an item to the cart and show a success message
                function addToCart(productName) {
                    // Retrieve the cart from sessionStorage (if it exists)
                    let cart = JSON.parse(sessionStorage.getItem('cart')) || [];

                    // Add the product to the cart
                    cart.push(productName);

                    // Save the updated cart back to sessionStorage
                    sessionStorage.setItem('cart', JSON.stringify(cart));

                    // Show the success message
                    alert(productName + " has been successfully added to the cart.");
                }


                // Simple JavaScript function to add the item to the wishlist
                function addToWishlist(productName) {
                    // Example: You could use AJAX or save to session/local storage
                    alert(productName + " has been added to your wishlist.");
                }

                // Function to redirect to the cart page
                function showcart() {
                    window.location.href = 'cart.php'; // Redirect to the cart page
                }
            </script>
        </section>

    </main>

    <footer>
        <!-- Menu -->
        <div id="footer-menu" class="footer-section">
            <!-- Bottom Navigation Menu -->

            <nav>
                <ul>
                    <li class="currentPage">Home</li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="catalogue.php">Catalogue</a></li>
                    <li><a href="cart.php"><img src="_images/cart_icon.jpeg" alt="Cart Icon" width="20"> Cart</a></li>
                    <li><a href="signup.php">Sign Up</a></li>
                    <li><a href="user_login.php">Log In</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li><a href="user_dashboard.php">Dashboard</a></li>
                    <li><a href="admin_login.php">Admin</a></li>
                </ul>
            </nav>

        </div>

        <div id="footer-content">
            <!-- Lets Connect -->
            <div id="social-media-footer" class="footer-section">
                <h4>Lets Connect</h4>
                <div>
                    <a href="https://www.instagram.com/moni_que360" target="_blank">
                        <img src="_images/instagram_icon.jpg" alt="Instagram Icon" width="3%"> @moni_que360</a>
                </div>
                <div>
                    <a href="https://www.facebook.com/pastime.fb/" target="_blank">
                        <img src="_images/facebook_icon.jpg" alt="Facebook Icon" width="3%"> Facebook</a>
                </div>
                <!-- Email -->
                <div>
                    <p><a href="mailto:pastimes23@gmail.com">pastimes23@gmail.com</a></p>
                </div>
            </div>
            <!-- Contact Information -->
            <div id="contact-info-footer-left" class="footer-section">
                <!-- Address -->
                <div class="address">
                    <h4><u>Address</u></h4>
                    <p><img src="_images/location_icon.jpg" alt="Address Icon" width="5%"> 19 Lyster Crescent, <br>
                        Randpark Ridge, <br>
                        Randburg, Johannesburg, 2169</p>
                </div>
                <!-- Working Hours -->
                <div class="working-hours">
                    <h4><u>Working hours:</u></h4>
                    <p class="no-break">Monday to Saturday: Open 24 hours</p>
                    <p class="no-break">Sunday: Closed</p>
                </div>
            </div>
        </div>
        <!-- Copyright and Last Modified Date -->
        <p>
            <?php
            echo "&copy; " . date("Y") . " - Pastimes | Last modified: " . date("F d, Y", filemtime(__FILE__));
            ?>
            <br>Powered by "Sustainable Fashion" Solutions
        </p>
    </footer>

</body>

</html>
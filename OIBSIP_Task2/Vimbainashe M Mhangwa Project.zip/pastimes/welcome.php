<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Pastimes is your go-to online store for high-quality branded used clothing, offering top-notch fashion at affordable prices.">
    <meta name="keywords" content="clothing store, online shopping, used clothing, affordable fashion, Pastimes, fashion">
    <meta name="revisit" content="30 days">
    <meta http-equiv="refresh" content="30">
    <meta name="robots" content="noindex, nofollow">
    <title>Welcome to Pastimes: Your Fashion Destination</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <div class="welcome-container">
        <h1>Welcome to Pastimes!</h1>
        <img src="_images/pastimes_logo.png" alt="Welcome Image">

        <p>Pastimes is your go-to shop for branded used clothing in great condition. Discover unique styles and enjoy sustainable shopping! </p>

        <a class="button" href="user_login.php">Click here to sign in</a>
        <a class="button" href="signup.php">Click here to register</a>
        <a class="button" href="index.php">Click here to go to Homepage </a> 
    </div>
</body>

</html>
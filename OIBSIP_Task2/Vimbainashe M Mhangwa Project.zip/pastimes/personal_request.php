<?php
session_start();

// Include database connection
include 'DBConn.php';

// Check if a filter is selected
$statusFilter = isset($_POST['statusFilter']) ? $_POST['statusFilter'] : 'pending'; // Default filter is 'pending'

// Fetch requests based on the selected status filter
$requestQuery = "SELECT sr.requestID, u.userID, u.username, sr.requestDate 
                 FROM seller_requests sr 
                 JOIN tbluser u ON sr.userID = u.userID 
                 WHERE sr.status = ?";

// Prepare the statement to prevent SQL injection
if ($dbConnection) {
    $stmt = $dbConnection->prepare($requestQuery);
    $stmt->bind_param("s", $statusFilter); // Bind the selected status filter to the query

    // Execute the query
    if ($stmt->execute()) {
        $result = $stmt->get_result();

        echo "<h2>Seller Requests</h2>";

        // Display filter options
        echo "<form method='POST' action=''>
                <label for='statusFilter'>Filter by status:</label>
                <select name='statusFilter' id='statusFilter' onchange='this.form.submit()'>
                    <option value='pending' " . ($statusFilter == 'pending' ? 'selected' : '') . ">Pending</option>
                    <option value='approved' " . ($statusFilter == 'approved' ? 'selected' : '') . ">Approved</option>
                    <option value='rejected' " . ($statusFilter == 'rejected' ? 'selected' : '') . ">Rejected</option>
                </select>
              </form>";

        // Check if there are any requests
        if ($result->num_rows > 0) {
            echo "<table><tr><th>Username</th><th>Request Date</th><th>Actions</th></tr>";
            while ($row = $result->fetch_assoc()) {
                echo "<tr><td>{$row['username']}</td><td>{$row['requestDate']}</td>";
                echo "<td>
                        <form method='POST' action='handle_request.php'>
                            <input type='hidden' name='requestID' value='{$row['requestID']}'>
                            <button type='submit' name='approve'>Approve</button>
                            <button type='submit' name='reject'>Reject</button>
                        </form>
                      </td></tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No requests found for this status.</p>";
        }
    } else {
        echo "<p style='color: red;'>Error in query: " . $dbConnection->error . "</p>";
    }
    $stmt->close();
}

?>

<button class="btn" type="button" onclick="window.location.href='admin_management.php';">Back to Admin Dashboard</button>

<?php
session_start();

// Debug to check if form data is received
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    echo 'Form submitted!<br>';
    var_dump($_POST); // Check posted data
    var_dump($_FILES); // Check uploaded files
} else {
    echo 'No form submitted.<br>';
}

// Include database connection
include 'DBConn.php';

// Check if the form is submitted and if a file is uploaded
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['image'])) {

    // 1. Define the upload directory relative to the web root
    $uploadDir = '_Images/'; // Folder where images will be stored

    // 2. Extract the original file name
    $imageName = basename($_FILES['image']['name']);

    // 3. Generate a unique name for the file to avoid overwriting
    $uniqueImageName = uniqid() . '_' . $imageName;

    // 4. Define the full server path where the file will be stored
    $imagePath = $uploadDir . $uniqueImageName;

    // 5. Ensure the directory exists, if not, create it
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true); // Create the directory with appropriate permissions
    }

    // 6. Validate the uploaded file
    $allowedTypes = [
        'image/jpeg', 
        'image/png', 
        'image/gif',
        'image/webp', // Allow WebP
        'image/jpg',
        'image/bmp', // Allow BMP if needed
        'image/tiff' // Allow TIFF if needed
    ];
    
    $fileType = mime_content_type($_FILES['image']['tmp_name']);

    if (in_array($fileType, $allowedTypes)) {
        // 7. Move the file from the temporary directory to the target directory
        if (move_uploaded_file($_FILES['image']['tmp_name'], $imagePath)) {
            echo "Image uploaded successfully!<br>";

            // Construct the URL to access the image in the browser
            $imageURL = 'http://localhost/pastimes/' . $imagePath;

            // Display the uploaded image
            echo '<img src="' . htmlspecialchars($imageURL, ENT_QUOTES) . '" alt="Uploaded Image" width="300">';
        } else {
            echo "Failed to upload the image.";
        }
    } else {
        echo "Invalid file type. Only JPG, PNG, GIF, and WEBP files are allowed.";
    }
} else {
    echo "No file uploaded.";
}

// Display the uploaded image if it exists
if ($uploadedImage) {
    echo '<h3>Uploaded Image:</h3>';
    echo '<img src="' . $uploadedImage . '" alt="Uploaded Image" width="300" style="border:1px solid #000;">';
}

// Close database connection if needed
// $dbConnection->close();
?>

<?php
session_start();

// Include database connection
include 'DBConn.php';  // This should set the $dbConnection variable correctly

// Check if the user is logged in
if (!isset($_SESSION['userID'])) {
    // If not logged in, redirect to login page
    header("Location: user_login.php");
    exit();
}

// Get the current user's ID from the session
$userID = $_SESSION['userID'];

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['become_seller'])) {
    // Prepare the SQL query to insert the seller request into the database
    $query = "INSERT INTO seller_requests (userID, requestDate, status) VALUES (?, NOW(), 'pending')";

    // Use $dbConnection here instead of $conn
    if ($stmt = $dbConnection->prepare($query)) {
        // Bind the userID parameter
        $stmt->bind_param("i", $userID);

        // Execute the query
        if ($stmt->execute()) {
            echo "<p>Your request to become a seller has been submitted and is pending admin approval.</p>";
        } else {
            echo "<p>There was an error processing your request. Please try again later.</p>";
        }

        // Close the statement
        $stmt->close();
    } else {
        echo "<p>There was an error with the database query. Please try again later.</p>";
    }
}
?>

    <button class="btn" type="button" onclick="window.location.href='user_dashboard.php';">Back to Dashboard</button>

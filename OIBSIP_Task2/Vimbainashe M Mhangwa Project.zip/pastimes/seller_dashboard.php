<?php
session_start();

// Include database connection
include 'DBConn.php';

// Initialize variables
$itemToEdit = null; // Default, no item to edit

// Handle fetching the item to edit
if (isset($_GET['action']) && $_GET['action'] === 'edit' && isset($_GET['itemID'])) {
    $itemID = $_GET['itemID'];
    $editQuery = "SELECT * FROM tbl_item WHERE item_id=$itemID";
    $result = $dbConnection->query($editQuery);
    $itemToEdit = $result->fetch_assoc(); // Fetch the item details to pre-populate the form
}


// Handle adding/updating item with image upload
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $itemName = $_POST['item_name'];
    $itemDescription = $_POST['item_description'];
    $price = $_POST['price'];
    $size = $_POST['size'];
    $color = $_POST['color'];
    $stockQuantity = $_POST['stock_quantity'];
    $category = $_POST['category'];
    $clothesCondition = $_POST['clothes_condition'];
    $itemID = isset($_POST['item_id']) ? $_POST['item_id'] : null;

    // Handle image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'C:\\wamp\\www\\pastimes\\_Images\\'; // Directory to store images
        $imageName = basename($_FILES['image']['name']);
        $imagePath = $uploadDir . uniqid() . '_' . $imageName; // Prevent overwriting files

        // Create the directory if it doesn't exist
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        // Move the uploaded file to the server
        if (move_uploaded_file($_FILES['image']['tmp_name'], $imagePath)) {
            echo "Image uploaded successfully!";
        } else {
            echo "Image upload failed!";
        }
    }

    // Insert or update item
    if ($itemID) {
        // Update existing item
        $updateQuery = "UPDATE tbl_item SET item_name = '$itemName', item_description = '$itemDescription', price = '$price', size = '$size', color = '$color', stock_quantity = '$stockQuantity', category = '$category', clothesCondition = '$clothesCondition', image_path = '$imagePath' WHERE item_id = $itemID";
        if ($dbConnection->query($updateQuery)) {
            echo "Item updated successfully!";
        } else {
            echo "Error: " . $dbConnection->error;
        }
    } else {
        // Insert new item
        $insertQuery = "INSERT INTO tbl_item (item_name, item_description, price, size, color, stock_quantity, category, clothesCondition, image_path) VALUES ('$itemName', '$itemDescription', '$price', '$size', '$color', '$stockQuantity', '$category', '$clothesCondition', '$imagePath')";
        if ($dbConnection->query($insertQuery)) {
            echo "Item added successfully!";
        } else {
            echo "Error: " . $dbConnection->error;
        }
    }
}

// Handle deleting item
if (isset($_GET['action']) && $_GET['action'] === 'delete') {
    $itemID = $_GET['itemID'];
    $deleteQuery = "DELETE FROM tbl_item WHERE item_id = $itemID";
    if ($dbConnection->query($deleteQuery)) {
        echo "Item deleted!";
    } else {
        echo "Error: " . $dbConnection->error;
    }
}

// Fetch all items
$query = "SELECT * FROM tbl_item";
$result = $dbConnection->query($query);

// Messages

// Fetch unread messages for the user/seller
$messageQuery = "SELECT message, timestamp, messageID FROM admin_messages 
                 WHERE recipientID = ? AND recipientType = ? AND status = 'unread' 
                 ORDER BY timestamp DESC";
$stmt = $dbConnection->prepare($messageQuery);

if ($stmt) {
    $stmt->bind_param("is", $userID, $role);
    $stmt->execute();
    $messageResult = $stmt->get_result();

    if ($messageResult->num_rows > 0) {
        echo "<h2>New Messages from Admin:</h2>";

        // Display each unread message
        while ($messageRow = $messageResult->fetch_assoc()) {
            echo "<p><strong>Message:</strong> " . htmlentities($messageRow['message']) . "</p>";
            echo "<p><em>Received on:</em> " . $messageRow['timestamp'] . "</p>";

            // Display the reply form for each message
            echo "<form method='POST'>
                    <textarea name='reply' required rows='4' cols='50'></textarea><br><br>
                    <button type='submit' name='sendReply' value='" . $messageRow['messageID'] . "'>Send Reply</button>
                  </form><hr>";
        }

        // Mark messages as read after displaying
        $updateStatusQuery = "UPDATE admin_messages SET status = 'read' WHERE recipientID = ? AND recipientType = ? AND status = 'unread'";
        $updateStmt = $dbConnection->prepare($updateStatusQuery);
        $updateStmt->bind_param("is", $userID, $role);
        $updateStmt->execute();
    } else {
        echo "<p>No new messages from the admin.</p>";
    }

    $stmt->close();
} else {
    echo "<p>Error fetching messages.</p>";
}

// Handle the reply submission
if (isset($_POST['sendReply'])) {
    $reply = $_POST['reply'];  // User's reply message
    $messageID = $_POST['sendReply'];  // The ID of the message being replied to
    $timestamp = date("Y-m-d H:i:s");

    // Insert the reply into the message_replies table
    $insertReplyQuery = "INSERT INTO message_replies (messageID, senderID, replyMessage, timestamp) 
                         VALUES (?, ?, ?, ?)";
    $replyStmt = $dbConnection->prepare($insertReplyQuery);

// Assuming you're already connected to the database with a $dbconnection variable

// Define the SQL query
$query = "INSERT INTO admin_messages (recipientID, recipientType, message, status, timestamp) 
          VALUES (?, ?, ?, ?, ?)";

// Prepare the statement
$adminMessageStmt = $dbConnection->prepare($query);

if ($adminMessageStmt) {
    // Assuming the necessary values are retrieved from user input or other sources
    $reply = $_POST['reply'];  // Or wherever you get the reply content
    $timestamp = date('Y-m-d H:i:s');  // Current timestamp

    $recipientID = 1;  // Assuming recipientID of '1' is the admin (or dynamic value)
    $recipientType = 'user';  // Assuming recipientType is 'user' (adjust as needed)
    $status = 'unread';  // Or any other status you want to assign

    // Bind the parameters to the statement
    $adminMessageStmt->bind_param("issss", $recipientID, $recipientType, $reply, $status, $timestamp);

    // Execute the query
    if ($adminMessageStmt->execute()) {
        echo "<p>Your reply has been sent successfully!</p>";
    } else {
        echo "<p>Error sending your message to admin: " . $adminMessageStmt->error . "</p>";
    }

    // Close the statement
    $adminMessageStmt->close();
} else {
    echo "<p>Error preparing admin message query: " . $dbConnection->error . "</p>";
}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Pastimes is your go-to online store for high-quality branded used clothing, offering top-notch fashion at affordable prices.">
    <meta name="keywords" content="clothing store, online shopping, used clothing, affordable fashion, Pastimes, fashion">
    <meta name="revisit" content="30 days">
    <meta http-equiv="refresh" content="30">
    <meta name="robots" content="noindex, nofollow">
    <title>Pastimes Seller Dashboard </title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="css/lightbox.css" media="screen" />

</head>

<div class="container">

    <!-- Display logged-in user's name -->
    <?php
    if (isset($_SESSION['name'])) {
        // Display the logged-in message
        echo "<p>User " . htmlspecialchars($_SESSION['name']) . " is logged in.</p>";
    } else {
        // Display a message for users who are not logged in
        echo "<p>Welcome, guest! Please log in to access more features.</p>";
    }
    ?>
</div>

<body>
    <div class="seller-container">
        <a href="logout.php" class="logout-btn">Logout</a><br>
        <a href="seller_messages.php">View Messages</a><br>

        <h1 class="seller-heading">Seller Dashboard</h1>


        <!-- Form to Add or Update an Item -->
        <form method="POST" action="" enctype="multipart/form-data" class="seller-form">
            <input type="hidden" name="item_id" value="<?php echo isset($itemToEdit) ? $itemToEdit['item_id'] : ''; ?>">
            <input type="text" name="item_name" placeholder="Item Name" value="<?php echo isset($itemToEdit) ? $itemToEdit['item_name'] : ''; ?>" required>
            <textarea name="item_description" placeholder="Item Description" required><?php echo isset($itemToEdit) ? $itemToEdit['item_description'] : ''; ?></textarea>
            <input type="number" name="price" placeholder="Price" step="0.01" value="<?php echo isset($itemToEdit) ? $itemToEdit['price'] : ''; ?>" required>
            <input type="text" name="size" placeholder="Size" value="<?php echo isset($itemToEdit) ? $itemToEdit['size'] : ''; ?>" required>
            <input type="text" name="color" placeholder="Color" value="<?php echo isset($itemToEdit) ? $itemToEdit['color'] : ''; ?>" required>
            <input type="number" name="stock_quantity" placeholder="Stock Quantity" value="<?php echo isset($itemToEdit) ? $itemToEdit['stock_quantity'] : ''; ?>" required>
            <select name="category" required>
                <option value="Men" <?php echo (isset($itemToEdit) && $itemToEdit['category'] === 'Men') ? 'selected' : ''; ?>>Men</option>
                <option value="Women" <?php echo (isset($itemToEdit) && $itemToEdit['category'] === 'Women') ? 'selected' : ''; ?>>Women</option>
                <option value="Children" <?php echo (isset($itemToEdit) && $itemToEdit['category'] === 'Children') ? 'selected' : ''; ?>>Children</option>
            </select>
            <select name="clothes_condition" required>
                <option value="New" <?php echo (isset($itemToEdit) && $itemToEdit['clothesCondition'] === 'New') ? 'selected' : ''; ?>>New</option>
                <option value="Like New" <?php echo (isset($itemToEdit) && $itemToEdit['clothesCondition'] === 'Like New') ? 'selected' : ''; ?>>Like New</option>
                <option value="Good" <?php echo (isset($itemToEdit) && $itemToEdit['clothesCondition'] === 'Good') ? 'selected' : ''; ?>>Good</option>
                <option value="Fair" <?php echo (isset($itemToEdit) && $itemToEdit['clothesCondition'] === 'Fair') ? 'selected' : ''; ?>>Fair</option>
                <option value="Poor" <?php echo (isset($itemToEdit) && $itemToEdit['clothesCondition'] === 'Poor') ? 'selected' : ''; ?>>Poor</option>
            </select>

            <!-- Image upload input -->
            <input type="file" name="image" accept="image/*" required>

            <button type="submit" name="<?php echo isset($itemToEdit) ? 'update_item' : 'add_item'; ?>">
                <?php echo isset($itemToEdit) ? 'Update Item' : 'Add Item'; ?>
            </button>
        </form>


        <!-- Display List of Items -->
        <table class="seller-table">
            <thead>
                <tr>
                    <th>Item ID</th>
                    <th>Name</th>
                    <th>Description</th>
                    <th>Price</th>
                    <th>Size</th>
                    <th>Color</th>
                    <th>Stock</th>
                    <th>Category</th>
                    <th>Condition</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($result->num_rows > 0): ?>
                    <?php while ($item = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $item['item_id']; ?></td>
                            <td><?php echo htmlspecialchars($item['item_name'], ENT_QUOTES); ?></td>
                            <td><?php echo htmlspecialchars($item['item_description'], ENT_QUOTES); ?></td>
                            <td><?php echo number_format($item['price'], 2); ?></td>
                            <td><?php echo htmlspecialchars($item['size'], ENT_QUOTES); ?></td>
                            <td><?php echo htmlspecialchars($item['color'], ENT_QUOTES); ?></td>
                            <td><?php echo $item['stock_quantity']; ?></td>
                            <td><?php echo htmlspecialchars($item['category'], ENT_QUOTES); ?></td>
                            <td><?php echo htmlspecialchars($item['clothesCondition'], ENT_QUOTES); ?></td>
                            <td>
                                <?php if ($item['image_path']): ?>
                                    <a href="<?php echo htmlspecialchars($item['image_path'], ENT_QUOTES); ?>" target="_blank">
                                        <img src="<?php echo htmlspecialchars($item['image_path'], ENT_QUOTES); ?>" alt="<?php echo htmlspecialchars($item['item_name'], ENT_QUOTES); ?>" style="width: 50px; height: 50px;">
                                    </a>
                                <?php else: ?>
                                    No Image
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="?action=edit&itemID=<?php echo $item['item_id']; ?>" class="edit-btn">Edit</a>
                                <a href="?action=delete&itemID=<?php echo $item['item_id']; ?>" class="delete-btn" onclick="return confirm('Are you sure you want to delete this item?');">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="10">No items found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <script src="js/lightbox-plus-jquery.js"></script>
</body>

</html>

</html>
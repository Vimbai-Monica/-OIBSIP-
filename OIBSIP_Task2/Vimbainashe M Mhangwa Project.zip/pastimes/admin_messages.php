<?php
session_start();

// Include database connection
include 'DBConn.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Send Message</title>
</head>
<body>
    <h1>Welcome Admin</h1>

    <h2>Send a Message</h2>

    <!-- Form to send a message to either a user or seller -->
    <form method="POST" action="admin_messages.php">
        <label for="recipientType">Send message to:</label>
        <select name="recipientType" id="recipientType">
            <option value="user">User</option>
            <option value="seller">Seller</option>
        </select>

        <label for="recipientID">Enter ID:</label>
        <input type="text" name="recipientID" id="recipientID" required><br>

        <label for="message">Message:</label><br>
        <textarea name="message" id="message" rows="4" cols="50" required></textarea><br>

        <button type="submit" name="sendMessage">Send Message</button>
    </form>

    <?php
    // Check if the send message button was clicked
    if (isset($_POST['sendMessage'])) {
        $recipientType = $_POST['recipientType']; // 'user' or 'seller'
        $recipientID = $_POST['recipientID']; // ID of the recipient
        $message = $_POST['message'];
        $timestamp = date("Y-m-d H:i:s");

        // Check if recipientID is numeric (to prevent SQL injection issues)
        if (is_numeric($recipientID)) {
            // Insert the message into the admin_messages table
            $insertQuery = "INSERT INTO admin_messages (recipientID, recipientType, message, status, timestamp)
                            VALUES (?, ?, ?, 'unread', ?)";
            $stmt = $dbConnection->prepare($insertQuery);

            if ($stmt) {
                // Bind parameters: recipientID (integer), recipientType (string), message (text), timestamp (string)
                $stmt->bind_param("isss", $recipientID, $recipientType, $message, $timestamp);
                if ($stmt->execute()) {
                    echo "<p>Message sent successfully!</p>";
                } else {
                    echo "<p>Error sending message.</p>";
                }
                $stmt->close();
            } else {
                echo "<p>Error preparing the statement.</p>";
            }
        } else {
            echo "<p>Invalid recipient ID.</p>";
        }
    }
    ?>
</body>
</html>

<br>
<a href="admin_management.php" class="button">Back to Admin Dashboard</a>

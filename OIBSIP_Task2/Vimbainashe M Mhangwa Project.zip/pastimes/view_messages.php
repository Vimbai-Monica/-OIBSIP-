<?php
session_start();

// Include database connection
include 'DBConn.php';


// Fetch all messages for the admin
$adminMessageQuery = "SELECT * FROM admin_messages WHERE recipientType IN ('user', 'seller','admin') ORDER BY timestamp DESC";

$adminMessageStmt = $dbConnection->prepare($adminMessageQuery);

if ($adminMessageStmt) {
    $adminMessageStmt->execute();
    $adminMessageResult = $adminMessageStmt->get_result();

    if ($adminMessageResult->num_rows > 0) {
        echo "<h2>Messages from Users/Sellers:</h2>";

        // Display each admin message
        while ($adminMessageRow = $adminMessageResult->fetch_assoc()) {
            echo "<div class='message'>";
            echo "<p><strong>Message:</strong> " . htmlentities($adminMessageRow['message']) . "</p>";
            echo "<p><em>Received on:</em> " . $adminMessageRow['timestamp'] . "</p>";

            // Fetch replies for this message
            $messageID = $adminMessageRow['messageID'];
            $replyQuery = "SELECT replyMessage, timestamp, senderID FROM message_replies WHERE messageID = ? ORDER BY timestamp DESC";
            $replyStmt = $dbConnection->prepare($replyQuery);
            $replyStmt->bind_param("i", $messageID);
            $replyStmt->execute();
            $replyResult = $replyStmt->get_result();

            if ($replyResult->num_rows > 0) {
                echo "<h3>Replies:</h3>";
                // Display each reply
                while ($replyRow = $replyResult->fetch_assoc()) {
                    $senderID = $replyRow['senderID'];

                    // Prepare the query to get the sender's role
                    $senderRoleQuery = "SELECT role FROM tbluser WHERE userID = ?";
                    $senderRoleStmt = $dbConnection->prepare($senderRoleQuery);

                    if ($senderRoleStmt === false) {
                        // If preparing the query fails, output the error and stop execution
                        die("Error preparing the statement: " . $dbConnection->error);
                    }

                    // Bind the parameter and execute
                    $senderRoleStmt->bind_param("i", $senderID);

                    if (!$senderRoleStmt->execute()) {
                        // If execution fails, show the error and stop execution
                        die("Error executing the statement: " . $senderRoleStmt->error);
                    }

                    // Get the result of the executed query
                    $senderRoleResult = $senderRoleStmt->get_result();

                    if ($senderRoleResult->num_rows > 0) {
                        // Fetch the role from the result
                        $senderRoleRow = $senderRoleResult->fetch_assoc();
                        $senderRole = htmlentities($senderRoleRow['role']);
                    } else {
                        // If no role is found, set it to 'Unknown'
                        $senderRole = 'Unknown';
                    }

                    // Display the reply and sender's role
                    echo "<p><strong>From:</strong> " . $senderRole . "</p>";
                    echo "<p><strong>Reply:</strong> " . htmlentities($replyRow['replyMessage']) . "</p>";
                    echo "<p><em>Received on:</em> " . $replyRow['timestamp'] . "</p><hr>";
                }
            } else {
                echo "<p>No replies yet.</p>";
            }

            echo "</div><hr>";
        }
    } else {
        echo "<p>No messages from users/sellers.</p>";
    }

    $adminMessageStmt->close();
} else {
    echo "<p>Error fetching messages.</p>";
}

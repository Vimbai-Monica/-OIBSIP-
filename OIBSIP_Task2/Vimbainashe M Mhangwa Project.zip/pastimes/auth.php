<?php
// Start the session if it hasn't been started yet
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Function to check if the user is logged in
function checkLogin() {
    if (!isset($_SESSION['userID'])) {
        // Show a JavaScript alert to notify the user they need to log in or sign up
        echo "<script>
                alert('Login or sign up to access this page.');
                window.location.href = 'index.php'; // Redirect to homepage after the alert
              </script>";
        
        // Stop further execution after displaying the alert
        exit();
    }
    return true; // User is logged in, return true
}

// Restrict access to pages for logged-in users only
function restrictAccess() {
    // Check if the user is logged in, if not, show the alert and redirect
    checkLogin();
}
?>

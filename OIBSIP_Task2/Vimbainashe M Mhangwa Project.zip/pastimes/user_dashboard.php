<?php
session_start();  // Only call session_start() once

include 'DBConn.php';  // Ensure the DBConn.php file correctly initializes $dbConnection
include 'auth.php'; // Include the authentication code
checkLogin(); // Check if the user is logged in

// Fetch the user ID from the session
$userID = $_SESSION['userID']; // assuming userID is stored in session after login

// Ensure that $dbConnection is initialized in the DBConn.php file
if (!$dbConnection) {
    die("Database connection failed.");
}

// Fetch user data
$sql = "SELECT * FROM tbluser WHERE userID = $userID";
$result = $dbConnection->query($sql);

if ($result) {
    $user = $result->fetch_assoc();
} else {
    echo "Error fetching user data: " . $dbConnection->error;
    exit;
}

// Fetch orders
$orderSql = "SELECT * FROM tblaorder WHERE userID = $userID";
$orderResult = $dbConnection->query($orderSql);

// Fetch payment history
$paymentSql = "SELECT * FROM tblaorder WHERE userID = $userID";
$paymentResult = $dbConnection->query($paymentSql);

// Fetch total purchases
$totalSql = "SELECT SUM(totalAmount) AS totalAmount FROM tblaorder WHERE userID = $userID";
$totalResult = $dbConnection->query($totalSql);
$total = $totalResult->fetch_assoc()['totalAmount'];

// Request to become a seller
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['become_seller'])) {
    $sql = "UPDATE tbluser SET role = 'seller' WHERE userID = $userID";
    if ($dbConnection->query($sql)) {
        echo "You have successfully requested to become a seller. Please wait for admin approval.";
    } else {
        echo "Error: " . $dbConnection->error;
    }
}

// Fetch the current user's seller request status
$requestQuery = "SELECT status FROM seller_requests WHERE userID = ? ORDER BY requestDate DESC LIMIT 1";
$stmt = $dbConnection->prepare($requestQuery);

if ($stmt) {
    $stmt->bind_param("i", $userID);
    $stmt->execute();
    $requestResult = $stmt->get_result();

    // Check if a request exists
    $requestStatus = $requestResult->fetch_assoc();

    if ($requestStatus) {
        // Check the status of the request
        if ($requestStatus['status'] == 'pending') {
            echo "<p>Your request to become a seller is pending admin approval.</p>";
        } elseif ($requestStatus['status'] == 'approved') {
            echo "<p>Your request to become a seller has been approved. Please click <a href='seller_dashboard.php'>here</a> to access the seller dashboard.</p>
";
        } else {
            echo "<p>Your request to become a seller was rejected by the admin.</p>";
        }
    } else {
?>
<?php
    }
}

// Messages

// Get the logged-in user's ID and role (user or seller) from the session
$userID = $_SESSION['userID'];
$role = $_SESSION['role']; // Assuming 'role' is either 'user' or 'seller'

// Fetch unread messages for the user/seller
$messageQuery = "SELECT message, timestamp, messageID FROM admin_messages 
                 WHERE recipientID = ? AND recipientType = ? AND status = 'unread' 
                 ORDER BY timestamp DESC";
$stmt = $dbConnection->prepare($messageQuery);

if ($stmt) {
    $stmt->bind_param("is", $userID, $role);
    $stmt->execute();
    $messageResult = $stmt->get_result();

    if ($messageResult->num_rows > 0) {
        echo "<h2>New Messages from Admin:</h2>";

        // Display each unread message
        while ($messageRow = $messageResult->fetch_assoc()) {
            echo "<p><strong>Message:</strong> " . htmlentities($messageRow['message']) . "</p>";
            echo "<p><em>Received on:</em> " . $messageRow['timestamp'] . "</p>";

            // Display the reply form for each message
            echo "<form method='POST'>
                    <textarea name='reply' required rows='4' cols='50'></textarea><br><br>
                    <button type='submit' name='sendReply' value='" . $messageRow['messageID'] . "'>Send Reply</button>
                  </form><hr>";
        }

        // Mark messages as read after displaying
        $updateStatusQuery = "UPDATE admin_messages SET status = 'read' WHERE recipientID = ? AND recipientType = ? AND status = 'unread'";
        $updateStmt = $dbConnection->prepare($updateStatusQuery);
        $updateStmt->bind_param("is", $userID, $role);
        $updateStmt->execute();
    } else {
        echo "<p>No new messages from the admin.</p>";
    }

    $stmt->close();
} else {
    echo "<p>Error fetching messages.</p>";
}

// Handle the reply submission
if (isset($_POST['sendReply'])) {
    $reply = $_POST['reply'];  // User's reply message
    $messageID = $_POST['sendReply'];  // The ID of the message being replied to
    $timestamp = date("Y-m-d H:i:s");

    // Insert the reply into the message_replies table
    $insertReplyQuery = "INSERT INTO message_replies (messageID, senderID, replyMessage, timestamp) 
                         VALUES (?, ?, ?, ?)";
    $replyStmt = $dbConnection->prepare($insertReplyQuery);

    // Assuming you're already connected to the database with a $dbconnection variable

    // Define the SQL query
    $query = "INSERT INTO admin_messages (recipientID, recipientType, message, status, timestamp) 
          VALUES (?, ?, ?, ?, ?)";

    // Prepare the statement
    $adminMessageStmt = $dbConnection->prepare($query);

    if ($adminMessageStmt) {
        // Assuming the necessary values are retrieved from user input or other sources
        $reply = $_POST['reply'];  // Or wherever you get the reply content
        $timestamp = date('Y-m-d H:i:s');  // Current timestamp

        $recipientID = 1;  // Assuming recipientID of '1' is the admin (or dynamic value)
        $recipientType = 'user';  // Assuming recipientType is 'user' (adjust as needed)
        $status = 'unread';  // Or any other status you want to assign

        // Bind the parameters to the statement
        $adminMessageStmt->bind_param("issss", $recipientID, $recipientType, $reply, $status, $timestamp);

        // Execute the query
        if ($adminMessageStmt->execute()) {
            echo "<p>Your reply has been sent successfully!</p>";
        } else {
            echo "<p>Error sending your message to admin: " . $adminMessageStmt->error . "</p>";
        }

        // Close the statement
        $adminMessageStmt->close();
    } else {
        echo "<p>Error preparing admin message query: " . $dbConnection->error . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Pastimes is your go-to online store for high-quality branded used clothing, offering top-notch fashion at affordable prices.">
    <meta name="keywords" content="clothing store, online shopping, used clothing, affordable fashion, Pastimes, fashion">
    <meta name="revisit" content="30 days">
    <meta http-equiv="refresh" content="30">
    <meta name="robots" content="noindex, nofollow">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="style.css"> <!-- External CSS -->
</head>

<body>
    <header>
        <div class="header-container">
            <div class="logo-container">
                <img src="_images/pastimes_logo.png" alt="Pastimes Logo" width="150">
            </div>

            <div class="search-container">
                <input type="text" placeholder="Search for items..." class="search-bar" id="search-input">
                <button class="search-button" id="search-button">Search</button>
            </div>

            <script>
                document.getElementById('search-button').addEventListener('click', function() {
                    const query = document.getElementById('search-input').value;
                    if (query) {
                        // Perform the search action here. For example, you can redirect to a search results page:
                        alert('Searching for: ' + query); // Replace this line with your search functionality
                        // window.location.href = 'search-results.html?query=' + encodeURIComponent(query);
                    } else {
                        alert('Please enter a search term.');
                    }
                });

                // Optional: Enable searching by pressing Enter in the input field
                document.getElementById('search-input').addEventListener('keypress', function(event) {
                    if (event.key === 'Enter') {
                        document.getElementById('search-button').click();
                    }
                });
            </script>

            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="about.php">About</a></li>
                    <li><a href="catalogue.php">Catalogue</a></li>
                    <li><a href="cart.php"><img src="_images/cart_icon.jpeg" alt="Cart Icon" width="20"> Cart</a></li>
                    <li><a href="contact.php">Contact Us</a></li>
                    <li class="currentPage">Dashboard</li>
                    <li><a href="logout.php">Log Out</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Display logged-in user's name -->
    <?php
    if (isset($_SESSION['name'])) {
        // Display the logged-in message
        echo "<p>User " . htmlspecialchars($_SESSION['name']) . " is logged in.</p>";
    } else {
        // Display a message for users who are not logged in
        echo "<p>Welcome, guest! Please log in to access more features.</p>";
    }
    ?>
    <main>
        <section id="hero">


            <div class="dashboard-container">


                <div class="sidebar">
                    <h3>Welcome, <?php echo $user['name']; ?></h3>

                    <a href="#order-status">Track Orders</a><br>
                    <a href="#order-history">Order History</a></br>
                    <a href="#payment-history">Payment History</a><br>
                    <a href="#personal-info">Personal Info</a><br>
                    <a href="#report">Generate Report</a><br>
                    <a href="#Messages">Messages</a>

                </div>





                <div class="main-content">
                    <div id="order-status">
                        <h2>Order Status</h2>
                        <?php if ($orderResult->num_rows > 0) {
                            while ($order = $orderResult->fetch_assoc()) {
                                echo "<p>Order #" . $order['orderID'] . " - Status: " . $order['orderStatus'] . "</p>";
                            }
                        } else {
                            echo "<p>No orders found.</p>";
                        } ?>
                    </div>

                    <div id="order-history">
                        <h2>Order History</h2>
                        <?php
                        if ($orderResult->num_rows > 0) {
                            echo "<table><tr><th>Order ID</th><th>Order Number</th><th>Reference Number</th><th>Session ID</th><th>Status</th><th>Total</th></tr>";
                            while ($order = $orderResult->fetch_assoc()) {
                                // Fetch order details
                                $orderID = $order['orderID'];
                                $order_number = isset($_SESSION['orderNumber']) ? $_SESSION['orderNumber'] : 'N/A';  // From session if set
                                $reference_number = isset($_SESSION['referenceNumber']) ? $_SESSION['referenceNumber'] : 'N/A';  // From session if set
                                $sessionID = isset($_SESSION['sessionID']) ? $_SESSION['sessionID'] : 'N/A';  // From session if set
                                $orderStatus = $order['orderStatus'];
                                $total_amount = $order['totalAmount'];

                                // Output order data
                                echo "<tr><td>" . $orderID . "</td><td>" . $order_number . "</td><td>" . $reference_number . "</td><td>" . $sessionID . "</td><td>" . $orderStatus . "</td><td>" . $total_amount . "</td></tr>";
                            }
                            echo "</table>";
                        } else {
                            echo "<p>No order history available.</p>";
                        }
                        ?>
                    </div>



                    <div id="payment-history">
                        <h2>Payment History</h2>
                        <?php if ($paymentResult->num_rows > 0) {
                            echo "<table><tr><th>Payment Date</th><th>Amount</th></tr>";
                            while ($payment = $paymentResult->fetch_assoc()) {
                                echo "<tr><td>" . $payment['orderDate'] . "</td><td>" . $payment['totalAmount'] . "</td></tr>";
                            }
                            echo "</table>";
                        } else {
                            echo "<p>No payment history found.</p>";
                        } ?>
                    </div>

                    <div id="personal-info">
                        <h2>Personal Information</h2>
                        <p>Name: <?php echo $user['name']; ?></p>
                        <p>Email: <?php echo $user['email']; ?></p>
                        <p>Role: <?php echo $user['role']; ?></p>
                    </div>

                    <div id="report">
                        <h2>Purchase Report</h2>
                        <p>Total Purchases: R<?php echo number_format($total, 2); ?></p>
                    </div>

                    <h2>Your Messages</h2>

                    <div id="Messages">
                        <?php
                        // Fetch unread messages for the user
                        $messageQuery = "SELECT message, timestamp, messageID FROM admin_messages 
    WHERE recipientID = ? AND status = 'unread' 
    ORDER BY timestamp DESC";
                        $stmt = $dbConnection->prepare($messageQuery);

                        if ($stmt) {
                            $stmt->bind_param("i", $userID);
                            $stmt->execute();
                            $messageResult = $stmt->get_result();

                            // Check if there are any messages
                            if ($messageResult->num_rows > 0) {
                                // Display each message
                                while ($messageRow = $messageResult->fetch_assoc()) {
                                    echo "<p><strong>Message:</strong> " . htmlentities($messageRow['message']) . "</p>";
                                    echo "<p><em>Received on:</em> " . $messageRow['timestamp'] . "</p>";

                                    // Display the reply form for each message
                                    echo "<form method='POST'>
       <textarea name='reply' required rows='4' cols='50'></textarea><br><br>
       <button type='submit' name='sendReply' value='" . $messageRow['messageID'] . "'>Send Reply</button>
     </form><hr>";
                                }

                                // Mark messages as read after displaying
                                $updateStatusQuery = "UPDATE admin_messages SET status = 'read' WHERE recipientID = ? AND status = 'unread'";
                                $updateStmt = $dbConnection->prepare($updateStatusQuery);
                                $updateStmt->bind_param("i", $userID);
                                $updateStmt->execute();
                            } else {
                                echo "<p>No new messages.</p>";
                            }

                            $stmt->close();
                        } else {
                            echo "<p>Error fetching messages.</p>";
                        }

                        // Handle the reply submission
                        if (isset($_POST['sendReply'])) {
                            $reply = $_POST['reply']; // User's reply
                            $messageID = $_POST['sendReply']; // The ID of the message being replied to
                            $timestamp = date("Y-m-d H:i:s");

                            // Insert the reply into the database
                            $insertReplyQuery = "INSERT INTO message_replies (messageID, senderID, replyMessage, timestamp) 
            VALUES (?, ?, ?, ?)";
                            $replyStmt = $dbConnection->prepare($insertReplyQuery);

                            if ($replyStmt) {
                                $replyStmt->bind_param("iiss", $messageID, $userID, $reply, $timestamp);
                                if ($replyStmt->execute()) {
                                    echo "<p>Your reply has been sent successfully!</p>";
                                } else {
                                    echo "<p>Error sending your reply.</p>";
                                }
                                $replyStmt->close();
                            }
                        }
                        ?>
                    </div>


                    <form method="POST" action="request_seller.php">
                        <button type="submit" name="become_seller">Request to Become a Seller</button>
                    </form>
                </div>
            </div>

        </section>

    </main>

    <div id="footer-content">
        <!-- Lets Connect -->
        <div id="social-media-footer" class="footer-section">
            <h4>Lets Connect</h4>
            <div>
                <a href="https://www.instagram.com/moni_que360" target="_blank">
                    <img src="_images/instagram_icon.jpg" alt="Instagram Icon" width="3%"> @moni_que360</a>
            </div>
            <div>
                <a href="https://www.facebook.com/pastime.fb/" target="_blank">
                    <img src="_images/facebook_icon.jpg" alt="Facebook Icon" width="3%"> Facebook</a>
            </div>
            <!-- Email -->
            <div>
                <p><a href="mailto:pastimes23@gmail.com">pastimes23@gmail.com</a></p>
            </div>
        </div>
        <!-- Contact Information -->
        <div id="contact-info-footer-left" class="footer-section">
            <!-- Address -->
            <div class="address">
                <h4><u>Address</u></h4>
                <p><img src="_images/location_icon.jpg" alt="Address Icon" width="5%"> 19 Lyster Crescent, <br>
                    Randpark Ridge, <br>
                    Randburg, Johannesburg, 2169</p>
            </div>
            <!-- Working Hours -->
            <div class="working-hours">
                <h4><u>Working hours:</u></h4>
                <p class="no-break">Monday to Saturday: Open 24 hours</p>
                <p class="no-break">Sunday: Closed</p>
            </div>
        </div>
    </div>
    </footer>
</body>

</html>